## Work Plan

-Always make directory for any controller related views
-Keep standard Code Alignment
-Keep JS CSS in public
-Keep Custom JS at init.js
-Don't write text in blade. Use Language File
-read the migration files cartefully


## Sohag Hasan
-Products CRUD
-Sale
-Live

## MRZ Rashed
-Mastering 
-Purchase

## Rokon
-cart
-Spatie
-Search