<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExpressOrderDetails extends Model
{
    //
    protected $fillable=['exporder_id','name','brand','qty'];

}
