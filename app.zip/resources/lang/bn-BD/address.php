<?php

return [
    'Billing Address' =>'লেনদেনের ঠিকানা',
    'Shipping Address' =>'প্রেরণের ঠিকানা',
    'Add New' =>'নতুন ঠিকানা',
    'Edit' =>'পরিবর্তন করুন',
];
?>
