<?php

return [
    'Login' => 'লগইন',
    'Email' => 'ই-মেইল',
    'Password' => 'পাসওয়ার্ড',
    'Registration' => 'রেজিট্রেশন',
    'forgot' => 'পাসওয়ার্ড ভুলে গেছেন?',
    'remember' => 'লগইন থাকুন',
    'Name' => 'নাম (ইংরেজি)',
    'Name_bn' => 'নাম (বাংলা)',
    'ConfirmPassword' => 'পুনরায় পাসওয়ার্ড',
];
?>
