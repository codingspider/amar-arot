<?php
return [
    'Order no'=>'অর্ডার নং',
    'Date'=>'তারিখ',
    'Price'=>'মুল্য',
    'Status'=>'অবস্থা',
    'Details'=>'বিস্তারিত',
    'Sales Arrangement'=>'ব্যবস্থা',
    'Confired'=>'কনফার্ম হয়েছে',
    'Confired Order'=>'কনফার্ম করুন',
    'Not Confired'=>'এখনো কনফার্ম হয়নি',
    'In the Courier'=>'কুরিয়ারে আছে',
    'Delivered'=>'ডেলিভারি হয়েছে',
    'Sales Orders'=>'বিক্রয় অর্ডার সমূহ',
    'Purchase Orders'=>'ক্রয় অর্ডার সমূহ',
    'Your orders'=>'আপনার অর্ডার সমূহ',
    'Shipment'=>'চালান দিন',
    'Your order details'=>'আপনার অর্ডার বিস্তারিত',
    'Address'=>'ঠিকানাঃ',
    'Saler Name'=>'বিক্রেতার নামঃ',
    'Buyer Name'=>'ক্রেতার নামঃ',
    'Note'=>'নোটঃ',
    'Booking memo no'=>'বুকিং মেমো নংঃ',
    'New Order' => 'নতুন আদেশ'
];
?>
