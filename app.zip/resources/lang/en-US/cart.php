<?php

return [
    'Total' => 'Total:',
    'Taka' => 'Taka',
    'Product Name' => 'Product Name',
    'Quantity' => 'Quantity',
    'Unit Price' => 'Unit Price',
    'Sub Total' => 'Sub Total',
    'Confirm' => 'Confirm Order',
    'Kg'=>'KG',
    'Action'=>'Action',
    'Save for Later'=>'Save for Later',
    'Continue Shopping'=>'Continue Shopping',
    'Have a Code?'=>'Have a Code?',
    'Apply'=>'Apply',
    'Move to Cart'=>'Move to Cart',
    'There is no items in your cart!'=>'There is no items in your cart!',
    'Shop Now'=>'Shop Now',
    'Saved For Later'=>'Saved For Later',
    'item(s)'=>'item(s)',
    'coupons'=>'Coupons',
    'coupons_creat'=>'Coupons Create',
    'code'=>'Coupons Code ',
    'type'=>'Coupons Type ',
    'value'=>'Coupons Value',
    'percent_off'=>'Percent Off',
    'brand' => 'Brand'
];
?>
