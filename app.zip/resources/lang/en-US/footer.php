<?php

return [
    'Bio' => 'We are a team of fresh graduates and young professionals who are seriously affected by Covid 19 facing a situation of stopping our income. Your every purchase shall help us to live and work for the society for good. We also ensure you the fresh and green products to reach your door step at the best price.',
];
?>
