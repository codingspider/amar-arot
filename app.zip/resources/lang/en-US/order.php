<?php
return [
    'Order no'=>'Order No',
    'Date'=>'Date',
    'Price'=>'Price',
    'Status'=>'Status',
    'Details'=>'Details',
    'Arrangement'=>'Arrangement',
    'Confired'=>'Confired',
    'Confired Order'=>'Confired Order',
    'Not Confired'=>'Not Confired',
    'In the Courier'=>'In the Courier',
    'Delivered'=>'Delivered',
    'Sales Orders'=>'Sales Orders',
    'Purchase Orders'=>'Purchase Orders',
    'Your orders'=>'Your Orders',
    'Shipment'=>'Shipment',
    'Your order details'=>'Your Order Details',
    'Address'=>'Address:',
    'Saler Name'=>'Saler Name:',
    'Buyer Name'=>'Buyer Name:',
    'Note'=>'Note:',
    'Booking memo no'=>'Booking memo no:',

];
?>
