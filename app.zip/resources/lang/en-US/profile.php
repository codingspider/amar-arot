<?php

return [
    'Name' =>'Name',
    'Bangla Name' =>'Bangla Name',
    'Email' =>'Email',
    'website' =>'website',
    'facebook' =>'facebook',
    'phone' =>'phone',
    'edit' =>'Edit',
    'Update' =>'সংরক্ষণ করুণUpdate',

];
?>
