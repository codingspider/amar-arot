<?php $__env->startSection('contents'); ?>
<div class="container">

    <div class="row">
        <div class="col-md-12">
            <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
        </div>
    </div>


    <div class="row">
        <div class="col s12 m12">
            <div class="card">
                <div class="card-content text-center">
                    <table>
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>:</th>
                                <th><?php echo e($profile->name); ?></th>
                            </tr>
                            <tr>
                                <th>Bangla Name</th>
                                <th>:</th>
                                <th><?php echo e($profile->name_bn); ?></th>
                            </tr>
                            <tr>
                                <th>Email</th>
                                <th>:</th>
                                <th><?php echo e($profile->email); ?></th>
                            </tr>
                            <tr>
                                <th>website</th>
                                <th>:</th>
                                <th><?php echo e($profile->website); ?></th>
                            </tr>
                            <tr>
                                <th>facebook</th>
                                <th>:</th>
                                <th><?php echo e($profile->facebook); ?></th>
                            </tr>
                            <tr>
                                <th>phone</th>
                                <th>:</th>
                                <th><?php echo e($profile->phone); ?></th>
                            </tr>
                        </thead>
                    </table>
                </div>
                <div class="card-action">
                    <a href="<?php echo e(route('profiles.edit',$profile->id)); ?>" class="btn btn-link">Edit</a>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col s6 m6">

            <div class="row">
                <div class="col s12">
                    <div class="card">
                        <div class="card-action">
                            <h6>Billing Address <span><a href="<?php echo e(url('add-address/billing')); ?>" class="btn btn-link">Add
                                        New</a></span></h6>
                        </div>
                        <?php if(isset($billing)): ?>

                        <div class="card-content">
                            <div class="row">
                                <div class="col s12">
                                    <h6>Address Line 1:<?php echo e($billing->address_line_1); ?></h6>
                                    <h6><?php if(isset($billing->address_line_2)): ?>Address Line 2: <?php echo e($billing->address_line_2); ?>

                                        <?php endif; ?>
                                    </h6>
                                    <h6>District: <?php echo e($billing->name); ?></h6>
                                </div>
                            </div>
                        </div>
                        <div class="card-action">
                            <a href="<?php echo e(url('edit-address/'.$billing->id)); ?>" class="btn btn-link">Edit</a>
                        </div>
                        <?php endif; ?>

                    </div>
                </div>
            </div>


            <?php $__currentLoopData = $billing_histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $billing_history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row">
                <div class="col s12">
                    <div class="card">
                        <div class="card-action">
                            <h6>Billing Address <span><a href="<?php echo e(url('active-address/'.$billing_history->id)); ?>"
                                        class="btn btn-link">Active</a> <a
                                        href="<?php echo e(url('delete-address/'.$billing_history->id)); ?>"
                                        class="btn btn-danger">Delete</a>
                                </span></h6>

                        </div>
                        <div class="card-content">
                            <div class="row">
                                <div class="col s12">
                                    <h6>Address Line 1:<?php echo e($billing_history->address_line_1); ?></h6>
                                    <h6><?php if(isset($billing_history->address_line_2)): ?>Address Line 2:
                                        <?php echo e($billing_history->address_line_2); ?>

                                        <?php endif; ?>
                                    </h6>
                                    <h6>District: <?php echo e($billing_history->name); ?></h6>
                                </div>
                            </div>
                        </div>
                        <div class="card-action">
                            <a href="<?php echo e(url('edit-address/'.$billing_history->id)); ?>" class="btn btn-link">Edit</a>
                        </div>
                    </div>
                </div>
            </div>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="col s6 m6">
            <div class="row">
                <div class="col s12">
                    <div class="card">
                        <div class="card-action">
                            <h6>Shipping Address <span><a href="<?php echo e(url('add-address/shipping')); ?>"
                                        class="btn btn-link">Add New</a></span></h6>
                        </div>
                        <?php if(isset($shipping)): ?>

                        <div class="card-content">
                            <div class="row">
                                <div class="col s12">
                                    <h6>Address Line 1:<?php echo e($shipping->address_line_1); ?></h6>
                                    <h6><?php if(isset($shipping->address_line_2)): ?>Address Line 2:
                                        <?php echo e($shipping->address_line_2); ?> <?php endif; ?></h6>
                                    <h6>District:<?php echo e($shipping->name); ?></h6>
                                </div>
                            </div>
                        </div>
                        <div class="card-action">
                            <a href="<?php echo e(url('edit-address/'.$shipping->id)); ?>" class="btn btn-link">Edit</a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php $__currentLoopData = $shipping_histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipping_history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row">
                <div class="col s12">
                    <div class="card">
                        <div class="card-action">
                            <h6>Shipping Address <span><a href="<?php echo e(url('active-address/'.$shipping_history->id)); ?>"
                                        class="btn btn-link">Active</a> <a
                                        href="<?php echo e(url('delete-address/'.$shipping_history->id)); ?>"
                                        class="btn btn-danger">Delete</a>
                                </span></h6>
                        </div>
                        <div class="card-content">
                            <div class="row">
                                <div class="col s12">
                                    <h6>Address Line 1:<?php echo e($shipping_history->address_line_1); ?></h6>
                                    <h6><?php if(isset($shipping_history->address_line_2)): ?>Address Line 2:
                                        <?php echo e($shipping_history->address_line_2); ?> <?php endif; ?></h6>
                                    <h6>District:<?php echo e($shipping_history->name); ?></h6>
                                </div>
                            </div>
                        </div>
                        <div class="card-action">
                            <a href="<?php echo e(url('edit-address/'.$shipping_history->id)); ?>" class="btn btn-link">Edit</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\amarbazar-laravel\resources\views/profile/index.blade.php ENDPATH**/ ?>