<?php $__env->startSection('contents'); ?>


<br>
<?php if(count($errors) > 0): ?>
<div class="alert alert-danger">
    <strong>Whoops!</strong> There were some problems with your input.<br><br>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<div class="container">
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h4>Edit Role</h4>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('roles.index')); ?>"> Back</a>
            </div>
        </div>
    </div>
    <div class="row">
        <form class="col s12" action="<?php echo e(route('roles.update', $role->id)); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('PATCH')); ?>

            <div class="row">
                <div class="input-field col s12">
                    <input placeholder="Placeholder" name="name" type="text" value="<?php echo e($role->name); ?>" class="validate">
                    <label for="role_name">Role Name</label>
                </div>
                <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="input-field col s12 m3">
                    <label>
                        <input class="filled-in" name="permission[]" value="<?php echo e($value->id); ?>" type="checkbox"
                            <?php if(in_array($value->id, $rolePermissions)): ?> checked <?php endif; ?>/>
                        <span><?php echo e($value->name); ?></span>
                    </label>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <br>

            </div>
            <br>
            <br>
            <button type="submit" class="btn btn-primary">Submit </button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\amarbazar-laravel\resources\views/roles/edit.blade.php ENDPATH**/ ?>