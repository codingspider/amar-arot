<?php $__env->startSection('contents'); ?>
<br>
<div class="container">
    <div class="row">
        <div class="col s12">
            <div class="pull-left">
                <h2><?php echo e(__('user.users')); ?></h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="<?php echo e(route('users.create')); ?>"><?php echo e(__('user.new_user')); ?></a>
            </div>
        </div>
    </div>

    <table>
        <thead>
            <tr>
                <th><?php echo e(__('user.no')); ?></th>
                <th><?php echo e(__('user.name')); ?></th>
                <th><?php echo e(__('user.email')); ?></th>
                <th><?php echo e(__('user.role')); ?></th>
                <th width="300px"><?php echo e(__('user.action')); ?></th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(++$i); ?></td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td>
                    <?php if(!empty($user->getRoleNames())): ?>
                    <?php $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label class="badge badge-success black-text"><?php echo e($v); ?></label>,
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </td>
                <td>
                    <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <a class="btn btn-primary" href="<?php echo e(route('users.show',$user->id)); ?>"><?php echo e(__('user.show_user')); ?></a>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-edit')): ?>
                        <a class="btn btn-primary" href="<?php echo e(route('users.edit',$user->id)); ?>"><?php echo e(__('user.edit_user')); ?></a>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-delete')): ?>
                        <a class="btn waves-effect waves-light red lighten-2" type="submit"><?php echo e(__('user.delete_user')); ?></a>
                        <?php endif; ?>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo $data->render(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\amarbazar-laravel\resources\views/users/index.blade.php ENDPATH**/ ?>