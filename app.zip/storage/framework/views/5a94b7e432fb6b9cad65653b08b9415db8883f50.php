<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0" />
    <title><?php echo $__env->yieldContent('title','Optima'); ?></title>
    <!-- CSS  -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="<?php echo e(asset('content')); ?>/css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection" />
    <link href="<?php echo e(asset('content')); ?>/css/style.css" type="text/css" rel="stylesheet" media="screen,projection" />
</head>

<body>
    <?php echo $__env->yieldContent('auth'); ?>
    <!--  Scripts-->
    <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script src="<?php echo e(asset('content')); ?>/js/materialize.js"></script>
    <script src="<?php echo e(asset('content')); ?>/js/install.js"></script>
    <script src="<?php echo e(asset('content')); ?>/js/init.js"></script>

</body>

</html>
<?php /**PATH C:\laragon\www\amarbazar-laravel\resources\views/layouts/auth.blade.php ENDPATH**/ ?>