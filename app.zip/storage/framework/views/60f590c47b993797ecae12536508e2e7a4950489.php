<?php $__env->startSection('title','Welcome-AmarBazar'); ?>
<?php $__env->startSection('auth'); ?>
<div class="section no-pad-bot" id="index-banner">
    <div class="container">
        <br><br>
        <h1 class="header center light-blue-text"><?php echo e(__('welcome.Amar Bazar')); ?></h1>
        <div class="row center">
            <h5 class="header col s12 light"><?php echo e(__('welcome.Everything together')); ?></h5>
        </div>
        <div class="row center">
            <a href="<?php echo e(url('login')); ?>" id="download-button" class="btn-large waves-effect waves-light light-blue"><?php echo e(__('login.Login')); ?></a>
        </div>
        <br><br>

    </div>
</div>
<div class="container">
    <div class="section">
        <!--   Icon Section   -->
        <div class="row">
            <div class="col s12 m4">
                <div class="icon-block">
                    <h2 class="center light-blue-text"><i class="material-icons">flash_on</i></h2>
                    <h5 class="center"><?php echo e(__('welcome.Fast delivery')); ?></h5>

                    <p class="light center"><?php echo e(__('welcome.First of all')); ?></p>
                </div>
            </div>

            <div class="col s12 m4">
                <div class="icon-block">
                    <h2 class="center light-blue-text"><i class="material-icons">group</i></h2>
                    <h5 class="center"><?php echo e(__('welcome.Fast delivery')); ?></h5>

                    <p class="light center"><?php echo e(__('welcome.Do everything easily')); ?></p>
                </div>
            </div>

            <div class="col s12 m4">
                <div class="icon-block">
                    <h2 class="center light-blue-text"><i class="material-icons">settings</i></h2>
                    <h5 class="center"><?php echo e(__('welcome.Easy interface')); ?></h5>

                    <p class="light center"><?php echo e(__('welcome.Your information is under your control')); ?></p>
                </div>
            </div>
        </div>

    </div>
    <br><br>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\amarbazar-laravel\resources\views/welcome.blade.php ENDPATH**/ ?>