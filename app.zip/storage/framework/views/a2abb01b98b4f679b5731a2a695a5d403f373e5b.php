<?php $__env->startSection('contents'); ?>
<div class="container">

    <div class="row">
        <div class="col-md-12">
            <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="row mt-5">
        <div class="col-lg-12 margin-tb">
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('home')); ?>"> Back</a>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col s12 m12">
            <div class="card">
                <form action="<?php echo e(url('store-address')); ?>" method="POST">
                    <div class="card-action">
                        <p class="waves-effect waves-light btn"><?php if($type == 'billing'): ?>Billing Address <?php else: ?> Shipping Address <?php endif; ?></p>
                    </div>
                    <div class="card-content text-center">
                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="input-field col s12">
                                <input id="address_line_1" name="address_line_1" value="" type="text" class="validate">
                                <label for="address_line_1">Address line 1</label>
                                <input type="hidden" name="type" value="<?php echo e($type); ?>">
                            </div>
                        </div>
                        <div class="row">
                            <div class="input-field col s12">
                                <input id="address_line_2" name="address_line_2" value="" type="text" class="validate">
                                <label for="address_line_2">Address Line 2</label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="input-field col s12">
                                <select name="district_id" id="district_id" class="validate">
                                    <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($district->id); ?>"><?php echo e($district->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <label for="district_id">District</label>
                            </div>
                        </div>

                    </div>
                    <div class="card-action">
                        <button class="waves-effect waves-light btn" type="submit">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\amarbazar-laravel\resources\views/addresses/create.blade.php ENDPATH**/ ?>