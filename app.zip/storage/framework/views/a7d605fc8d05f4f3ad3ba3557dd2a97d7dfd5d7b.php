<?php $__env->startSection('pagetitle','Order-AmarBazar'); ?>

<?php $__env->startSection('contents'); ?>
<div class="section no-pad-bot" id="index-banner">
    <div class="container">
      <br><br>
      <h1 class="header center light-blue-text"><?php echo e(__('welcome.Amar Bazar')); ?></h1>
      <div class="row center">
        <h5 class="header col s12 light"><?php echo e(__('order.Your order details')); ?></h5>

      </div>
    </div>
  </div>


  <div class="container">
    <div class="section">

      <!--   Icon Section   -->
      <div class="row z-depth-1">
        <div class="col s12 m4">
          <p>
            <?php echo e(__('order.Buyer Name')); ?> <?php echo e(Auth::user()->name); ?> <br>
            Email :  <?php echo e(Auth::user()->email); ?> <br>
            <?php echo e(__('order.Address')); ?> <?php echo e($auth_user->address_line_1); ?>

          </p>
          </td>
        </div>
        <div class="col s12 m4">
          <p>
            <?php echo e(__('order.Saler Name')); ?> রহিম উদ্দিন <br>
            <?php echo e(__('product.Phone')); ?> ০১৭৩৩৩৩৩৩৩৩৩৩ <br>
            <?php echo e(__('order.Address')); ?> ঠাকুর গাঁও
          </p>
          </td>
        </div>
        <div class="col s12 m4">
          <p>
          <?php echo e(__('order.Status')); ?>: <?php echo e($status->status); ?><br>
            <?php echo e(__('order.Order no')); ?>: BUY00<?php echo e($status->order_id); ?> <br>
            <?php echo e(__('order.Note')); ?> <?php echo e(__('order.Booking memo no')); ?> ১২৪৮
          </p>
          </td>
        </div>
      </div>

      <div class="row">
        <div class="col s12 z-depth-1">
          <table class="responsive-table">
            <thead>
              <tr>
                <th><?php echo e(__('product.Product Name bn')); ?></th>
                <th><?php echo e(__('cart.Quantity')); ?></th>
                <th><?php echo e(__('cart.Unit Price')); ?>  </th>
                <th><?php echo e(__('cart.Sub Total')); ?> with (vat)</th>
              </tr>
            </thead>
            <?php
                $sum = 0;
            ?>
            <tbody>
              <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($item->name); ?></td>
                <td><?php echo e($item->quantity); ?></td>
                <td><?php echo e($item->price); ?></td>
                <td><?php echo e($act_points = ($item->quantity * $item->price)+ $item->vat); ?> </td>
                <td style="display:none;"><?php echo e($sum += $act_points); ?></td>
              </tr>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            </tbody>
          </table>
          <p class="center"><?php echo e(__('cart.Total')); ?> <?php echo e($sum); ?> <?php echo e(__('cart.Taka')); ?></p>
        </div>
      </div>
    </div>
    <br><br>
  </div>

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\amarbazar-laravel\resources\views/orders/show.blade.php ENDPATH**/ ?>