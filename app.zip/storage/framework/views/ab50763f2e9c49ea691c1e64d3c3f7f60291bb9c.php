<?php $__env->startSection('pagetitle','Purchase-AmarBazar'); ?>
<?php $__env->startSection('contents'); ?>
<div class="container">
    <div class="section">
        <div class="row">
            <div class="col s12 m12">
                <div class="row">
                    <div class="col s12 m6">
                        <div class="card">
                            <div class="card-image waves-effect waves-block waves-light">
                                <img class="activator" src="<?php echo e(asset('images/'.$product_details->image)); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="col s12 m6">
                        <div class="row">
                            <div class="col s12 m12">
                                <h2><?php echo e($product_details->name); ?></h2>
                            </div>
                            <div class="col s12 m12">
                                <h6><b>Category:</b> <?php echo e($categories->name); ?></h6>
                            </div>
                            <div class="col s12 m12">
                                <h6><b>Price:</b><?php echo e($product_details->price); ?></h6>
                            </div>
                            <div class="col s12 m12">
                                <h6><b>Stock:</b><?php echo e($product_details->stock_qty); ?><b><?php echo e(isset($measurmentUnit->name)); ?></b></h6>
                            </div>
                            <div class="col s12 m12">
                                <h6><b>Product Code:</b><?php echo e($product_details->product_code); ?></h6>
                            </div>
                            <div class="col s12 m12">
                                <h6><b>Seller: </b> <?php echo e($user->name); ?></h6>
                            </div>
                            <div class="col s12 m12">
                                <?php if($user->phone): ?><h6><b>Seller: </b> <?php echo e($user->phone); ?><?php endif; ?></h6>
                            </div>
                            <div class="col s12 m12">
                                <h6><?php if(!empty($address)): ?><b>Location: </b><?php echo e($address->name); ?><?php endif; ?></h6>
                            </div>
                            <div class="col s12 m12">
                                <form action="<?php echo e(route('cart.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php if(Cart::content()->where('id', $product_details->id)->count() >0): ?>
                                    <button class="btn light-blue disabled" type="submit">Already Added </button>
                                    <?php else: ?>
                                    <button class="btn light-blue " type="submit">Add to cart </button>
                                    <?php endif; ?>

                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col s12 m12">
                        <?php if($product_details->short_description): ?><h4>Short Description</h4>
                        <p class="flow-text"><?php echo e($product_details->short_description); ?></p><?php endif; ?>
                    </div>
                    <div class="col s12 m12">
                        <?php if($product_details->description): ?><h2>Description</h2>
                        <p class="flow-text"><?php echo e($product_details->description); ?></p><?php endif; ?>
                    </div>
                </div>

            </div>
        </div>

    </div>

    <br><br>
    <div class="section">
        <div class="row">
            <div class="col s12 m12">
                <h3 class="center-align">Realeted Product</h3>
            </div>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col s12 m3">
                <div class="card">
                    <div class="card-image waves-effect waves-block waves-light">
                        <img class="activator" src="<?php echo e(asset('uploads/'.$product->image)); ?>">
                    </div>
                    <div class="card-content">
                        <span class="card-title activator grey-text text-darken-4"><a
                                href="<?php echo e(route('details',$product->id)); ?>"
                                title="Product Details"><?php echo e($product->name); ?></a><i
                                class="material-icons right">more_vert</i></span>
                        
                        <form action="<?php echo e(route('cart.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                            <input type="hidden" name="name" value="<?php echo e($product->name); ?>">
                            <input type="hidden" name="price" value="<?php echo e($product->price); ?>">
                            <?php if(Cart::content()->where('id', $product->id)->count() >0): ?>
                            <button class="btn light-blue disabled" type="submit">Already Added </button>
                            <?php else: ?>
                            <button class="btn light-blue " type="submit">Add to cart </button>
                            <?php endif; ?>

                        </form>

                    </div>
                    <div class="card-reveal">
                        <span class="card-title grey-text text-darken-4"><?php echo e($product->name); ?><i
                                class="material-icons right">close</i></span>
                        <ul>
                            <li><?php echo e(__('product.Price')); ?> <?php echo e($product->price); ?><?php echo e(__('cart.Taka')); ?> <?php echo e(__('cart.Kg')); ?></li>
                            <li><?php echo e(__('product.Minimum Order')); ?> <?php echo e($product->stock_qty); ?><?php echo e(__('cart.Kg')); ?> </li>
                            <li><?php echo e(__('product.Place')); ?> <?php echo e($product->location); ?></li>
                            <li><?php echo e(__('product.Seller')); ?> <?php echo e($product->seller_name); ?></li>
                            <li><?php echo e(__('product.Phone')); ?> <?php echo e($product->phone); ?></li>

                        </ul>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>


<div class="fixed-action-btn">
    <?php if(Cart::count() > 0): ?>
    <a class="btn-floating btn-large red" href="<?php echo e(url('cart')); ?>"><?php echo e(Cart::instance('default')->count()); ?>

        <i class="large material-icons">add_shopping_cart</i>

    </a>
    <?php else: ?>
    <a class="btn-floating btn-large red" href="<?php echo e(url('cart')); ?>">
        <i class="large material-icons">add_shopping_cart</i>

    </a>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\amarbazar-laravel\resources\views/show.blade.php ENDPATH**/ ?>