<?php $__env->startSection('contents'); ?>
<br>
<div class="flash-message">
  <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if(Session::has('alert-' . $msg)): ?>
  <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?></p>
  <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="container">
  <div class="row">
    <form class="col s12" action="<?php echo e(route('products.store')); ?>" method="POST" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <div class="row">
        <div class="input-field col s6">
          <input id="name" name="name" type="text" class="validate">
          <label for="name"><?php echo e(__('product.Product Name en')); ?></label>
        </div>
        <div class="input-field col s6">
          <input id="name_bn" name="name_bn" type="text" class="validate">
          <label for="name_bn"><?php echo e(__('product.Product Name bn')); ?></label>
        </div>
      </div>
      <div class="row">
        <div class="input-field col s6">
          <input id="price" name="price" type="text" class="validate">
          <label for="price"><?php echo e(__('product.Selling Price')); ?></label>
        </div>
        <div class="input-field col s6">
          <input id="stock_qty" name="stock_qty" type="text" class="validate">
          <label for="stock_qty"><?php echo e(__('product.Stock')); ?></label>
        </div>
      </div>
      <div class="row">
        <div class="input-field col s6">
          <input id="rating" name="rating" type="text" class="validate">
          <label for="rating"><?php echo e(__('product.rating')); ?> </label>
        </div>
        <div class="input-field col s6">
          <input id="rating_by" name="rating_by" type="text" class="validate">
          <label for="rating_by"><?php echo e(__('product.rating_by')); ?> </label>
        </div>
      </div>
      <div class="row">
        <div class="input-field col s6">
          <input id="product_code" type="text" name="product_code" class="validate">
          <label for="product_code"><?php echo e(__('product.product_code')); ?></label>
        </div>
        <div class="input-field col s6">
          <input id="sale_price" type="text" name="sale_price" class="validate">
          <label for="sale_price"><?php echo e(__('product.sale_price')); ?> </label>
        </div>
      </div>
      <div class="row">
        <div class="input-field col s6">
          <input id="variation_type" type="text" name="variation_type" class="validate">
          <label for="variation_type"><?php echo e(__('product.product_variation')); ?> </label>
        </div>
        <div class="file-field col s6 input-field">
          <div class="btn light-blue">
            <span><?php echo e(__('product.Photo')); ?></span>
            <input type="file" name="images">
          </div>
          <div class="file-path-wrapper">
            <input class="file-path validate" type="text">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="input-field col s6">
          <textarea id="short_description" class="materialize-textarea" name="short_description"></textarea>
          <label for="short_description"><?php echo e(__('product.short_description')); ?></label>
        </div>
        <div class="input-field col s6">
          <textarea id="description" class="materialize-textarea" name="description"></textarea>
          <label for="description"><?php echo e(__('product.description')); ?> </label>
        </div>
      </div>
      <div class="row">
        <div class="input-field col s6">
          <textarea id="short_description_bn" class="materialize-textarea" name="short_description_bn"></textarea>
          <label for="short_description_bn"><?php echo e(__('product.short_description_bn')); ?> </label>
        </div>
        <div class="input-field col s6">
          <textarea id="description_bn" class="materialize-textarea" name="description_bn"></textarea>
          <label for="description_bn"><?php echo e(__('product.description_bn')); ?></label>
        </div>
      </div>
      <div class="row">
        <div class="input-field col s4">
          <select name="mesurment_id" name="measurment_unit_id">
            <option value="" selected>Choose your option</option>
            <?php $__currentLoopData = $measurement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </select>
          <label><?php echo e(__('product.measurement_id')); ?></label>
        </div>
        <div class="input-field col s4">
          <select name="cat_id" name="catagory_id">
            <option value="" selected>Choose your option</option>
             <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
          <label><?php echo e(__('product.category_id')); ?></label>
        </div>
        <div class="input-field col s4">
          <select name="seller_id" name="seller_id">
            <option value="" selected>Choose your option</option>
            <option value="1">Option 1</option>
            <option value="2">Option 2</option>
            <option value="3">Option 3</option>
          </select>
          <label><?php echo e(__('product.seller_id')); ?></label>
        </div>
      </div>
      <div class="row">
        <button type="submit" class="waves-effect waves-light btn"><i
            class="material-icons right">cloud</i><?php echo e(__('product.Save')); ?></button>
      </div>

    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\amarbazar-laravel\resources\views/products/create.blade.php ENDPATH**/ ?>