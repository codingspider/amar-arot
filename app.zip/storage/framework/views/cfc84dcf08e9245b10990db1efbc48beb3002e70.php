<?php $__env->startSection('pagetitle','Orders-AmarBazar'); ?>

<?php $__env->startSection('contents'); ?>
<div class="section no-pad-bot" id="index-banner">
    <div class="container">
      <br><br>
      <h1 class="header center light-blue-text"><?php echo e(__('welcome.Amar Bazar')); ?></h1>
      <div class="row center">
        <h5 class="header col s12 light"><?php echo e(__('order.Your orders')); ?></h5>
      </div>
    </div>
  </div>


  <div class="container">
    <div class="section">

      <!--   Icon Section   -->
      <div class="row">
        <div class="col s12 z-depth-1">
          <h5><?php echo e(__('order.Sales Orders')); ?></h5>
          <table class="responsive-table">
            <thead>
              <tr>
                <th><?php echo e(__('order.Order no')); ?></th>
                <th><?php echo e(__('order.Date')); ?></th>
                <th><?php echo e(__('order.Price')); ?></th>
                <th><?php echo e(__('order.Status')); ?></th>
                <th class="center"><?php echo e(__('order.Details')); ?></th>
                <th class="center"><?php echo e(__('order.Sales Arrangement')); ?></th>
              </tr>
            </thead>

            <tbody>
              <?php if(count($slae_orders) > 0): ?>
                  
              <?php $__currentLoopData = $slae_orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
              <tr>
                <td>BUY00<?php echo e($item->id); ?></td>
              <td><?php echo e(Carbon\Carbon::parse($item->created_at)->diffForHumans()); ?></td>
                <td><?php echo e($item->total_payable); ?> <?php echo e(__('cart.Taka')); ?></td>
                <td><?php echo e($item->status); ?></td>
                <td class="center"><a href="<?php echo e(url('details')); ?>" class="btn btn-sm light-blue"><?php echo e(__('order.Details')); ?></a></td>
                <td class="center"><button class="btn btn-sm green"><?php echo e(__('order.Shipment')); ?></button></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              <?php else: ?> 
              <h4>You have no orders!</h4>
              <?php endif; ?>

            </tbody>
          </table>
        </div>
      </div>
      <div class="row">
        <div class="col s12 z-depth-1">
          <h5><?php echo e(__('order.Purchase Orders')); ?></h5>
          <table class="responsive-table">
            <thead>
              <tr>
                <th><?php echo e(__('order.Order no')); ?></th>
                <th><?php echo e(__('order.Date')); ?></th>
                <th><?php echo e(__('order.Price')); ?></th>
                <th><?php echo e(__('order.Status')); ?></th>
                <th><?php echo e(__('order.Details')); ?></th>
              </tr>
            </thead>

            <tbody>
              <?php if(count($orders) > 0): ?>
                  
              <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
              <tr>
                <td>BUY00<?php echo e($item->id); ?></td>
                <td><?php echo e(Carbon\Carbon::parse($item->created_at)->diffForHumans()); ?></td>
                <td><?php echo e($item->total_payable); ?> <?php echo e(__('cart.Taka')); ?></td>
                <td><?php echo e($item->status); ?></td>
                <td><a href="<?php echo e(url('order/details/'.$item->id )); ?>" class="btn btn-sm light-blue"><?php echo e(__('order.Details')); ?></a></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              <?php else: ?> 
              <h4>You have no orders!</h4>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <br><br>
  </div>

  <div id="add_product" class="side_add_product sidenav">
    <div class="row">
      <form class="col s12">
        <div class="row">
          <div class="input-field col s12">
            <input id="first_name" type="text" class="validate">
            <label for="first_name"><?php echo e(__('product.Product Name')); ?></label>
          </div>
          <div class="input-field col s12">
            <input id="last_name" type="text" class="validate">
            <label for="last_name"><?php echo e(__('product.Selling Price')); ?></label>
          </div>
          <div class="input-field col s12">
            <input id="last_nam" type="text" class="validate">
            <label for="last_nam"><?php echo e(__('product.Stock')); ?></label>
          </div>
          <div class="input-field col s12">
            <input id="last_na" type="text" class="validate">
            <label for="last_na"><?php echo e(__('product.Transportation Cost')); ?></label>
          </div>
          <div class="input-field col s12">
            <input id="last_n" type="text" class="validate">
            <label for="last_n"><?php echo e(__('product.Minimum Sales amount')); ?></label>
          </div>
          <div class="file-field col s12 input-field">
            <div class="btn light-blue">
              <span><?php echo e(__('product.Photo')); ?></span>
              <input type="file">
            </div>
            <div class="file-path-wrapper">
              <input class="file-path validate" type="text">
            </div>
          </div>
          <div class="col s12 center">
            <button class="btn light-blue" type="submit"><?php echo e(__('product.Save')); ?></button>
          </div>
        </div>
      </form>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\amarbazar-laravel\resources\views/orders/index.blade.php ENDPATH**/ ?>