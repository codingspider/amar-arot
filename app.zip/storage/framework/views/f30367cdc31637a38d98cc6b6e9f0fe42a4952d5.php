<?php $__env->startSection('contents'); ?>
<br>
<div class="flash-message">
  <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if(Session::has('alert-' . $msg)): ?>
  <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?></p>
  <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="container">
  <div class="row">
    <form class="col s12" action="<?php echo e(route('catagories.store')); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <div class="row">
        <div class="input-field col s6">
          <input id="name" name="name" type="text" class="validate">
          <label for="name"><?php echo e(__('product.catagory_name_en')); ?></label>
        </div>
        <div class="input-field col s6">
          <input id="name_bn" name="name_bn" type="text" class="validate">
          <label for="name_bn"><?php echo e(__('product.catagory_name_bn')); ?></label>
        </div>
      </div>
        <div class="input-field col s4">
          <select name="main_catagory_id">
            <option value="" selected>---</option>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
          <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
          </select>
          <label><?php echo e(__('product.catagory_name_main')); ?></label>
        </div>
      </div>
      <div class="row">
        <button type="submit" class="waves-effect waves-light btn"><i
            class="material-icons right">cloud</i><?php echo e(__('product.Save')); ?></button>
      </div>

    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\amarbazar-laravel\resources\views/catagories/create.blade.php ENDPATH**/ ?>