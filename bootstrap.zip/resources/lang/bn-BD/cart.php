<?php

return [
    'Total' => 'মোটঃ',
    'Taka' => 'টাকা',
    'Product Name' => 'পন্যের নাম',
    'Quantity' => 'পরিমাণ',
    'Unit Price' => 'দর',
    'Sub Total' => 'দাম',
    'Confirm' => 'কনফার্ম করুন',
    'Kg' => 'কেজি',
    'Action' => 'কাজ',
    'Save for Later' => 'সংরক্ষণ করুন',
    'Continue Shopping' => 'আরও বাজার করুন',
    'Have a Code?' => 'আপনার কাছে কি কোড আছে?',
    'Apply' => 'আবেদন করুন',
    'Move to Cart' => 'ব্যাগে নিয়ে যান',
    'There is no items in your cart!' => 'আপনার ব্যাগে কোন বাজার নাই!',
    'Shop Now' => 'বাজার করুন',
    'Saved For Later' => 'সংরক্ষণ করা তথ্য',
    'item(s)' => 'টি',
    'brand' => 'ব্র্যান্ড',
    'vat' => '(ভ্যাট সহ)',
    'Add Row' => 'নতুন লাইন',
    'Confirm Order' => 'অর্ডার কনফার্ম করুন',
    'Order' => 'অর্ডার করুন',
    'Unit' => 'একক',
    'Delivery' => 'পরিবহন চার্জ'
];
