<?php
return [
    'Profile' => 'প্রোফাইল',
    'Sale' => 'বিক্রয়',
    'Orders' => 'অর্ডার সমূহ',
    'Install' => 'ইন্সটল',
    'Refresh' => 'রিফ্রেশ',
    'Manage_role' => 'ক্ষমতা ব্যবস্থাপনা',
    'Manage_user' => 'ব্যবহারকারী ব্যবস্থাপনা',
    'Manage_product' => 'পণ্য ব্যবস্থাপনা',
    'catagory' => 'ক্যাটাগরি ব্যবস্থাপনা',
    'measurments' => 'পরিমাপক ব্যবস্থাপনা',
    'logout' => 'লগআউট',
    'login' => 'লগইন',
    'Manage_order' => 'অর্ডার পরিচালনা করুন',
    'Express Order' => 'ফর্দ',
    'Manage_Express_order' => 'ফর্দ পরিচালনা করুন',

];
?>
