<?php

return [
    'Name' =>'নাম',
    'Bangla Name' =>'বাংলা নাম',
    'Email' =>'ইমেইল',
    'website' =>'ওয়েবসাইট',
    'facebook' =>'ফেসবুক',
    'phone' =>'মোবাইল',
    'edit' =>'পরিবর্তন করুণ',
    'Update' =>'সংরক্ষণ করুণ',

];
?>
