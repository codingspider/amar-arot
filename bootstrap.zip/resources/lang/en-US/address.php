<?php

return [
    'Billing Address' =>'Billing Address',
    'Shipping Address' =>'Shipping Address',
    'Add New' =>'Add New',
    'Edit' =>'Edit',
];
?>
