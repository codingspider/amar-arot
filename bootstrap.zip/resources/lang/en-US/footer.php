<?php

return [
    'Bio' => 'We are a team of fresh graduates and young entrepreneurs who have their dream implemented in starting of amararot.com. Our promise is to deliver the fresh and green products to reach your door step at the best price. Our vision is to build amararot.com family soaked with love and care. We welcome you to be part of the family. Thank you.',
];
?>
