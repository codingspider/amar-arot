<?php

return [
    'name' => 'Name (English)',
    'name_bn' => 'Name (Bangla)',
    'no' => 'No',
    'action' => 'Action',
    'edit' => 'Edit',
    'delete' => 'Delete',
];
?>
