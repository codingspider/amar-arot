<?php
return [
    'Profile' => 'Profile',
    'Sale' => 'Sale',
    'Orders' => 'Orders',
    'Install' => 'Install',
    'Refresh' => 'Refresh',
    'Manage_role' => 'Manage Role',
    'Manage_user' => 'Manage User',
    'Manage_product' => 'Manage Product',
    'catagory' => 'Manage Catagory',
    'measurments' => 'Manage Measurments',
    'logout' => 'Logout',
    'login' => 'Login',
    'Manage_order' => 'Manage Order',
    'Express Order' => 'Express Order',
    'Manage_Express_order' => 'Manage Express Order',

];
?>
