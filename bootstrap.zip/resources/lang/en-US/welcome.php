<?php

return [
    'Amar Bazar'=>'Amar Arot',
    'Everything together' => 'Everything together',
    'Fast delivery' => 'Fast delivery',
    'Easy interface' => 'Easy interface',
    'Under your control' => 'Under your control',
    'First of all' => 'First of all near to you',
    'Do everything easily' => 'Do everything easily',
    'Your information is under your control' => 'Your information is under your control',
];
?>
