<?php $__env->startSection('pagetitle','Order-AmarBazar'); ?>

<?php $__env->startSection('contents'); ?>
<div class="section no-pad-bot" id="index-banner">
    <div class="container">
        <br><br>
        <h1 class="header center light-blue-text"><?php echo e(__('welcome.Amar Bazar')); ?></h1>
        <div class="row center">
            <h5 class="header col s12 light"><?php echo e(__('order.Your order details')); ?></h5>
        </div>
    </div>
</div>

<div class="container">
    <div class="section">
        <!--   Icon Section   -->
        <div class="row">
            <div class="col s12">
                <?php if(session()->has('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('success')); ?>


                </div>
                <?php endif; ?>
            </div>
            <?php if($express_order->status == "Confirmed"): ?>
            <div class="collection">
                <?php if(empty(Auth::user()->phone)): ?>
                <a href="<?php echo e(route('profiles.show',Auth::user()->id)); ?>" target="_blank"
                    class="collection-item red-text">*Please Add Your Phone Number To Confirm The Order</a>
                <?php endif; ?>
                <?php if(count($billing)!=1): ?>
                <a href="<?php echo e(route('profiles.show',Auth::user()->id)); ?>" target="_blank"
                    class="collection-item red-text">*Please Add Your billing To Confirm The Order</a>
                <?php endif; ?>
                <?php if(count($shipping)!=1): ?>
                <a href="<?php echo e(route('profiles.show',Auth::user()->id)); ?>" target="_blank"
                    class="collection-item red-text">*Please Add Your Shipping To Confirm The Order</a>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
        <div class="row z-depth-1">
            <div class="col s12 m6">
                <p>
                    <?php echo e(__('order.Buyer Name')); ?> <?php echo e(Auth::user()->name); ?> <br>
                    <?php echo e(__('product.Phone')); ?> <?php echo e(Auth::user()->phone); ?> <br>
                    <?php echo e(__('order.Address')); ?> <?php if(!empty($address->address_line_1)): ?><?php echo e($address->address_line_1); ?><?php endif; ?>
                    <?php if(!empty($address->name)): ?><?php echo e($address->name); ?><?php endif; ?>
                </p>
            </div>
            <div class="col s12 m4">
                <p>
                    <?php echo e(__('order.Status')); ?>: <?php echo e($express_order->status); ?> <br>
                    <?php echo e(__('order.Order no')); ?>: <?php echo e($express_order->id); ?> <br>
                    <?php echo e(__('order.Date')); ?>:<?php echo e($express_order->created_at); ?>

                </p>
            </div>
            <div class="col s12 m2">
                <p>
                    <?php if($express_order->user_status =='1'): ?>
                    <a href="<?php echo e(route('express-orders.index')); ?>" class="btn"><?php echo e(__('order.Back')); ?></a>
                    <?php else: ?>
                    <?php if($express_order->status == "Confirmed"): ?>
                    <a href="<?php echo e(route('orderconfiramtion',$express_order->id)); ?>"
                        class="btn <?php if($express_order->user_status =='1'): ?>disabled <?php endif; ?>"><?php echo e(__('cart.Confirm')); ?></a>

                    <?php elseif($express_order->status == "Processing"): ?>
                    <a href="<?php echo e(route('orderconfiramtion',$express_order->id)); ?>" class="btn disabled">
                        <?php echo e(__('order.Confired')); ?></a>
                    <?php else: ?>
                    <a href="<?php echo e(route('express-orders.edit',$express_order->id)); ?>" class="btn"><?php echo e(__('order.Edit')); ?></a>
                    <?php endif; ?>
                    <form action="<?php echo e(route('express-orders.destroy',$express_order->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-red "><?php echo e(__('order.Cancel')); ?></button>
                    </form>
                    <?php endif; ?>
                </p>
            </div>
        </div>

        <div class="row">
            <div class="col s12 z-depth-1">
                <table class="responsive-table">
                    <thead>
                        <tr>
                        <tr>
                            <th><?php echo e(__('product.Product Name bn')); ?></th>
                            <th><?php echo e(__('cart.brand')); ?></th>
                            <th><?php echo e(__('cart.Quantity')); ?></th>
                            <th><?php echo e(__('cart.Unit')); ?></th>
                            <?php if($express_order->status == 'Confirmed'|| $express_order->status == 'Processing'): ?>
                            <th><?php echo e(__('cart.Unit Price')); ?></th>
                            <th><?php echo e(__('cart.Sub Total')); ?></th>
                            <?php endif; ?>
                        </tr>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $express_order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->name); ?></td>
                            <td><?php echo e($item->brand); ?></td>
                            <td><?php echo e($item->qty); ?></td>
                            <td><?php echo e($item->unit); ?></td>
                            <?php if($item->unit_price): ?>
                            <td><?php echo e($item->unit_price); ?></td>
                            <td><?php echo e($item->unit_price*$item->qty); ?></td>
                            <?php
                            $total_price += $item->unit_price*$item->qty;
                            ?>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($express_order->status == 'Confired'): ?>

                        <tr>
                            <td colspan="4"><?php echo e(__('cart.Total')); ?></td>
                            <td><?php echo e($total_price); ?></td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <br><br>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\amarbazar-laravel\resources\views/expressorders/show.blade.php ENDPATH**/ ?>