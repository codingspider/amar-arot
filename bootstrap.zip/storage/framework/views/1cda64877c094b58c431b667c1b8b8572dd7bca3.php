<?php $__env->startSection('pagetitle','Purchase-AmarBazar'); ?>
<?php $__env->startSection('contents'); ?>

<div class="section no-pad-bot" id="index-banner">
    <div class="container">
        <br><br>
        <h1 class="header center light-blue-text"><?php echo e(__('welcome.Amar Bazar')); ?></h1>
        <div class="row center">
            <h5 class="header col s12 light"><?php echo e(__('welcome.Everything together')); ?></h5>
            <div class="input-field inline">
                <input id="email_inline" type="email" class="validate">
                <label for="email_inline"><?php echo e(__('product.Search Box')); ?></label>
            </div>
            <div class="input-field inline">
                <button class="btn btn-sm light-blue" type="submit"><?php echo e(__('product.Search')); ?></button>
            </div>
        </div>
    </div>
</div>


<div class="container">
    <div class="section">

        <!--   Icon Section   -->
        <div class="row">
            <div class="col s12 m3">
                <div class="card">
                    <div class="card-image waves-effect waves-block waves-light">
                        <img class="activator" src="<?php echo e(asset('content')); ?>/img/product/anar.jpg">
                    </div>
                    <div class="card-content">
                        <span class="card-title activator grey-text text-darken-4">আনার<i
                                class="material-icons right">more_vert</i></span>
                        <p><a href="#" class="btn light-blue"><?php echo e(__('product.Add to Bag')); ?></a></p>
                    </div>
                    <div class="card-reveal">
                        <span class="card-title grey-text text-darken-4">আনার<i
                                class="material-icons right">close</i></span>
                        <ul>
                            <li><?php echo e(__('product.Price')); ?> ২৫০টাকা কেজি</li>
                            <li><?php echo e(__('product.Minimum Order')); ?> ৫কেজি</li>
                            <li><?php echo e(__('product.Place')); ?> ঢাকা</li>
                            <li><?php echo e(__('product.Seller')); ?> কামাল মিয়া</li>
                            <li> <?php echo e(__('product.Phone')); ?> ০১৭০০০০০০০০</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col s12 m3">
                <div class="card">
                    <div class="card-image waves-effect waves-block waves-light">
                        <img class="activator" src="<?php echo e(asset('content')); ?>/img/product/mango.jpg">
                    </div>
                    <div class="card-content">
                        <span class="card-title activator grey-text text-darken-4">আম<i
                                class="material-icons right">more_vert</i></span>
                        <p><a href="#" class="btn light-blue"><?php echo e(__('product.Add to Bag')); ?></a></p>
                    </div>
                    <div class="card-reveal">
                        <span class="card-title grey-text text-darken-4">আম<i
                                class="material-icons right">close</i></span>
                        <ul>
                            <li><?php echo e(__('product.Price')); ?> ২৫০টাকা কেজি</li>
                            <li><?php echo e(__('product.Minimum Order')); ?> ৫কেজি </li>
                            <li><?php echo e(__('product.Place')); ?> ঢাকা</li>
                            <li><?php echo e(__('product.Seller')); ?> কামাল মিয়া</li>
                            <li><?php echo e(__('product.Phone')); ?> ০১৭০০০০০০০০</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col s12 m3">
                <div class="card">
                    <div class="card-image waves-effect waves-block waves-light">
                        <img class="activator" src="<?php echo e(asset('content')); ?>/img/product/mango2.jpg">
                    </div>
                    <div class="card-content">
                        <span class="card-title activator grey-text text-darken-4">ফজলি আম<i
                                class="material-icons right">more_vert</i></span>
                        <p><a href="#" class="btn light-blue"><?php echo e(__('product.Add to Bag')); ?></a></p>
                    </div>
                    <div class="card-reveal">
                        <span class="card-title grey-text text-darken-4">ফজলি আম<i
                                class="material-icons right">close</i></span>
                        <ul>
                            <li><?php echo e(__('product.Price')); ?> ২৫০টাকা কেজি</li>
                            <li><?php echo e(__('product.Minimum Order')); ?> ৫কেজি </li>
                            <li><?php echo e(__('product.Place')); ?> ঢাকা</li>
                            <li><?php echo e(__('product.Seller')); ?> কামাল মিয়া</li>
                            <li><?php echo e(__('product.Phone')); ?> ০১৭০০০০০০০০</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col s12 m3">
                <div class="card">
                    <div class="card-image waves-effect waves-block waves-light">
                        <img class="activator" src="<?php echo e(asset('content')); ?>/img/product/orange.jpg">
                    </div>
                    <div class="card-content">
                        <span class="card-title activator grey-text text-darken-4">কমলা<i
                                class="material-icons right">more_vert</i></span>
                        <p><a href="#" class="btn light-blue"><?php echo e(__('product.Add to Bag')); ?></a></p>
                    </div>
                    <div class="card-reveal">
                        <span class="card-title grey-text text-darken-4">কমলা<i
                                class="material-icons right">close</i></span>
                        <ul>
                            <li><?php echo e(__('product.Price')); ?> ২৫০টাকা কেজি</li>
                            <li><?php echo e(__('product.Minimum Order')); ?> ৫কেজি </li>
                            <li><?php echo e(__('product.Place')); ?> ঢাকা</li>
                            <li><?php echo e(__('product.Seller')); ?> কামাল মিয়া</li>
                            <li><?php echo e(__('product.Phone')); ?> ০১৭০০০০০০০০</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <br><br>
</div>
<div class="fixed-action-btn">
    <a class="btn-floating btn-large red" href="<?php echo e(url('cart')); ?>">
        <i class="large material-icons">add_shopping_cart</i>
    </a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\amarbazar-laravel\resources\views/purchases/index.blade.php ENDPATH**/ ?>