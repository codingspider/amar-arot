<?php $__env->startSection('pagetitle','Orders-AmarBazar'); ?>

<?php $__env->startSection('contents'); ?>
<div class="section no-pad-bot" id="index-banner">
    <div class="container">
        <br><br>
        <h1 class="header center light-blue-text"><?php echo e(__('welcome.Amar Bazar')); ?></h1>
        <div class="row center">
            <h5 class="header col s12 light"><?php echo e(__('order.Your orders')); ?></h5>
        </div>
    </div>
</div>


<div class="container">
    <div class="section">
        <h5><a href="<?php echo e(route('admin.express-orders.create')); ?>" class="btn"><?php echo e(__('order.New Order')); ?></a></h5>

        <div class="row">
            <div class="col s12 z-depth-1">
                <table id="myTable" class="highlight">
                    <thead>
                        <tr>
                            <th><?php echo e(__('order.Order no')); ?></th>
                            <th><?php echo e(__('order.Date')); ?></th>
                            <th><?php echo e(__('order.Status')); ?></th>
                            <th><?php echo e(__('order.User Confirmation')); ?></th>
                            <th class="center"><?php echo e(__('order.Details')); ?></th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $exp_orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exp_order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($exp_order->id); ?></td>
                            <td><?php echo e($exp_order->created_at); ?></td>
                            <td><?php echo e($exp_order->status); ?><?php if($exp_order->read_status == '1'): ?><span
                                    class="new badge"></span><?php endif; ?></td>
                            <?php if(empty($exp_order->deleted_by)): ?>
                            <td>
                                <?php if($exp_order->user_status == '0'): ?> Pending <?php endif; ?>
                                <?php if($exp_order->user_status == '1'): ?> User Confirmed <?php endif; ?>
                            </td>
                            <?php else: ?>
                            <td><a href="#" class="btn disabled">Canceled</a></td>
                            <?php endif; ?>
                            <td class="center"><a href="<?php echo e(url('admin/express-orders/'.$exp_order->id)); ?>"
                                    class="btn btn-sm light-blue"><?php echo e(__('order.Details')); ?></a>
                                <?php if($exp_order->user_status == '1'): ?>
                                <a href="<?php echo e(route('admin.print_express_order',$exp_order->id)); ?>" target="_blank"
                                    class="btn"><?php echo e(__('order.Print')); ?></a>
                                <?php endif; ?>
                            </td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
    <br><br>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function () {
        $('#myTable').DataTable();
        $('select').formSelect();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\amarbazar-laravel\resources\views/admin/expressorders/index.blade.php ENDPATH**/ ?>