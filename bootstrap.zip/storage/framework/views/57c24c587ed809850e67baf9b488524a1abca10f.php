<?php $__env->startSection('contents'); ?>
    <div class="container">

        <?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

    </div>
<?php endif; ?>
        <table>
        <thead>
          <tr>
              <th>Name</th>
              <th>Item Stock</th>
              <th>Item Price</th>
              <th>Action </th>
          </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
          <tr>
          <td><?php echo e($item->name); ?></td>
          <td><?php echo e($item->stock_qty); ?></td>
          <td><?php echo e($item->price); ?></td>

            <td>
            <form action="<?php echo e(URL::to('change/order/status/form')); ?>" method="POST">
                <?php echo csrf_field(); ?>
            <input type="hidden" name="id" value="<?php echo e($item->status); ?>">
                <select name="name" id="myselect" onchange="this.form.submit()">
                    <option value="Confirmed">Confirmed</option>
                    <option value="Courier">Courier</option>
                    <option value="Delivered">Delivered</option>
                    <option value="Cancelled">Cancelled</option>
                </select>
            </form>
            </td>
          </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          
        </tbody>
      </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\amarbazar-laravel\resources\views/orders/status_change.blade.php ENDPATH**/ ?>