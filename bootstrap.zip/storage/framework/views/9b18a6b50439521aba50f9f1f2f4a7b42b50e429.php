<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(__('order.Order no')); ?>- <?php echo e($express_order->id); ?></title>
    <style>
        table {
            font-family: arial, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }
        td,
        th {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
        #contact{
            font-family: arial, sans-serif;
            width: 100%;
            border: none;
        }
        #contact td{
            border: none;
            line-height: 5px;;
        }
        h1{
            text-align: center;
        }
    </style>
</head>

<body onload="window.print()">
    <div class="div">
        <h1>Amar Arot</h1>

        <table id="contact">
            <tr>
                <td><?php echo e(__('order.Buyer Name')); ?></td>
                <td><?php echo e($user->name); ?></td>
            </tr>
            <tr>
                <td><?php echo e(__('product.Phone')); ?></td>
                <td> <?php echo e($user->phone); ?></td>
            </tr>
            <tr>
                <td><?php echo e(__('order.Address')); ?></td>
                <td><?php if(!empty($address->address_line_1)): ?><?php echo e($address->address_line_1); ?><?php endif; ?> <?php if(!empty($address->name)): ?><?php echo e($address->name); ?><?php endif; ?></td>
            </tr>
            <tr>
                <td><?php echo e(__('order.Date')); ?>:</td>
                <td><?php echo e($express_order->created_at); ?></td>
            </tr>
        </table>
    </div>
    <br>
    <br>
    <br>
    <table>
        <thead>
            <tr>
                <th><?php echo e(__('product.Product Name bn')); ?></th>
                <th><?php echo e(__('cart.brand')); ?></th>
                <th><?php echo e(__('cart.Quantity')); ?></th>
                <th><?php echo e(__('cart.Unit')); ?></th>
                <?php if($express_order->status == 'Confired' || $express_order->status == 'Processing'): ?>
                <th><?php echo e(__('cart.Unit Price')); ?></th>
                <th><?php echo e(__('cart.Sub Total')); ?></th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
        <tbody>
            <?php $__currentLoopData = $express_order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->name); ?></td>
                <td><?php echo e($item->brand); ?></td>
                <td><?php echo e($item->qty); ?></td>
                <td><?php echo e($item->unit); ?></td>
                <?php if($item->unit_price): ?>
                <td><?php echo e($item->unit_price); ?></td>
                <td><?php echo e($item->unit_price*$item->qty); ?></td>
                <?php
                $total_price += $item->unit_price*$item->qty;
                ?>
                <?php endif; ?>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
        <tfoot>
            <tr>
                <td colspan="5"><?php echo e(__('cart.Delivery')); ?></td>
                <td>100</td>
            </tr>
            <?php if($express_order->status == 'Confired'|| $express_order->status == 'Processing'): ?>
            <tr>
                <td colspan="5"><?php echo e(__('cart.Total')); ?></td>
                <td><?php echo e($total_price+100); ?></td>
            </tr>
            <?php endif; ?>
        </tfoot>
        </tbody>
    </table>
</body>

</html>
<?php /**PATH C:\laragon\www\amarbazar-laravel\resources\views/admin/expressorders/print.blade.php ENDPATH**/ ?>