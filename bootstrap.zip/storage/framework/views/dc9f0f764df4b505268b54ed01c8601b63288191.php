<?php $__env->startSection('contents'); ?>
<div class="container">
<br>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2><?php echo e(__('product.Catagory')); ?></h2>
            </div>
            <div class="pull-right">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('catagory-create')): ?>
                <a class="btn btn-success" href="<?php echo e(route('catagories.create')); ?>"> <?php echo e(__('product.Catagory_create')); ?></a>
                <?php endif; ?>
            </div>
        </div>
    </div>


    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>


    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Name</th>
            <th>Details</th>
            <th width="280px">Action</th>
        </tr>
	    <?php $__currentLoopData = $catagories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catagory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <tr>
	        <td><?php echo e(++$i); ?></td>
	        <td><?php echo e($catagory->name); ?></td>
	        <td><?php echo e($catagory->detail); ?></td>
	        <td>
                <form action="<?php echo e(route('catagories.destroy',$catagory->id)); ?>" method="POST">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('catagory-edit')): ?>
                    <a class="btn btn-primary" href="<?php echo e(route('catagories.edit',$catagory->id)); ?>">Edit</a>
                    <?php endif; ?>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('catagory-delete')): ?>
                    <button type="submit" class="btn btn-danger">Delete</button>
                    <?php endif; ?>
                </form>
	        </td>
	    </tr>
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>


    <?php echo $catagories->links(); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\amarbazar-laravel\resources\views/catagories/index.blade.php ENDPATH**/ ?>