<?php $__env->startSection('contents'); ?>
<div class="section no-pad-bot" id="index-banner">
    <div class="container">
        <br><br>
        <h1 class="header center light-blue-text"><?php echo e(__('welcome.Amar Bazar')); ?></h1>
        <div class="row center">
            <h5 class="header col s12 light"><?php echo e(__('product.Your Products')); ?></h5>
            <a data-target="add_product" class="waves-effect waves-light btn right light-blue sidenav-trigger"><i
                    class="material-icons left">add_box</i><?php echo e(__('product.Add New Products')); ?></a>
        </div>
    </div>
</div>


<div class="container">
    <div class="section">
        <div class="row">
            <div class="col s12">
                <?php if(session()->has('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('success')); ?>

                </div>
                <?php endif; ?>
                <?php if(session()->has('error')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('error')); ?>

                </div>
                <?php endif; ?>

                <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="section">

        <!--   Icon Section   -->
        <div class="row">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col s12 m3">
                <div class="card">
                    <div class="card-image waves-effect waves-block waves-light">
                        <img class="activator" src="<?php echo e(asset('uploads/'.$product->image)); ?>">
                    </div>
                    <div class="card-content">
                        <div class="row">
                            <div class="col s12">
                                <span class="card-title activator grey-text text-darken-4"><?php echo e($product->name); ?><i
                                        class="material-icons right">more_vert</i></span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col s8 ">
                                <span><a href="<?php echo e(route('sales.edit',$product->id)); ?>"
                                        class="btn light-blue left-align"><?php echo e(__('product.Edit')); ?></a> </span>

                            </div>
                            <div class="col s2 left-align">
                                <form action="<?php echo e(route('sales.destroy',$product->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn red"><i
                                            class="material-icons">delete_forever</i></button>
                                </form>
                            </div>
                        </div>

                    </div>
                    <div class="card-reveal">
                        <span class="card-title grey-text text-darken-4"><?php echo e($product->name); ?><i
                                class="material-icons right">close</i></span>
                        <ul>
                            <li><?php echo e(__('product.Price')); ?> <?php echo e($product->price); ?><?php echo e(__('cart.Taka')); ?> <?php echo e(__('cart.Kg')); ?></li>
                            <li><?php echo e(__('product.Minimum Order')); ?> <?php echo e($product->stock_qty); ?><?php echo e(__('cart.Kg')); ?> </li>
                            <li><?php echo e(__('order.Address')); ?> <?php echo e($product->location); ?></li>
                            <li><?php echo e(__('product.Seller')); ?> <?php echo e($product->seller_name); ?></li>
                            <li><?php echo e(__('product.Phone')); ?> <?php echo e($product->phone); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </div>
    <br><br>
</div>

<div id="add_product" class="side_add_product sidenav">
    <div class="row">
        <form class="col s12" action="<?php echo e(route('sales.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="input-field col s6">
                    <input id="name" name="name" value="<?php echo e(old('name')); ?>" type="text" class="validate">
                    <label for="name"><?php echo e(__('product.Product Name en')); ?></label>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="input-field col s6">
                    <input id="name_bn" name="name_bn" value="<?php echo e(old('name_bn')); ?>" type="text" class="validate">
                    <label for="name_bn"><?php echo e(__('product.Product Name bn')); ?></label>
                    <?php $__errorArgs = ['name_bn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="row">
                <div class="input-field col s6">
                    <input id="price" name="price" value="<?php echo e(old('price')); ?>" type="text" class="validate">
                    <label for="price"><?php echo e(__('product.Price')); ?></label>
                    <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="input-field col s6">
                    <input id="sale_price" value="<?php echo e(old('sale_price')); ?>" type="text" name="sale_price" class="validate">
                    <label for="sale_price"><?php echo e(__('product.Selling Price')); ?> </label>
                    <?php $__errorArgs = ['sale_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

            </div>
            <div class="row">
                <div class="input-field col s12">
                    <input id="stock_qty" name="stock_qty" value="<?php echo e(old('stock_qty')); ?>" type="text" class="validate">
                    <label for="stock_qty"><?php echo e(__('product.Stock')); ?></label>
                    <?php $__errorArgs = ['stock_qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="row">
                <div class="input-field col s12">
                    <textarea id="short_description" class="materialize-textarea"
                        name="short_description"><?php echo e(old('short_description')); ?></textarea>
                    <label for="short_description"><?php echo e(__('product.short_description')); ?></label>
                    <?php $__errorArgs = ['short_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="input-field col s12">
                    <textarea id="description" class="materialize-textarea" name="description"
                        ><?php echo e(old('description')); ?></textarea>
                    <label for="description"><?php echo e(__('product.description')); ?> </label>
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="row">
                <div class="input-field col s12">
                    <textarea id="short_description_bn" class="materialize-textarea" name="short_description_bn"
                        ><?php echo e(old('short_description_bn')); ?></textarea>
                    <label for="short_description_bn"><?php echo e(__('product.short_description_bn')); ?> </label>
                    <?php $__errorArgs = ['short_description_bn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="input-field col s12">
                    <textarea id="description_bn" class="materialize-textarea"
                        name="description_bn"><?php echo e(old('description_bn')); ?></textarea>
                    <label for="description_bn"><?php echo e(__('product.description_bn')); ?></label>
                    <?php $__errorArgs = ['description_bn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="row">
                <div class="input-field col s6">
                    <select name="measurment_unit_id">
                        <option value="" selected>Choose your option</option>
                        <?php $__currentLoopData = $measurements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>" <?php if(old('measurment_unit_id')==$item->id ): ?> selected <?php endif; ?>
                            ><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label><?php echo e(__('product.measurement_id')); ?></label>
                    <?php $__errorArgs = ['measurment_unit_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="input-field col s6">
                    <select name="catagory_id">
                        <option value="" selected>Choose your option</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>" <?php if(old('catagory_id')==$item->id ): ?> selected <?php endif; ?>
                            ><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label><?php echo e(__('product.category_id')); ?></label>
                    <?php $__errorArgs = ['catagory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="row">
                <div class="file-field col s12 input-field">
                    <div class="btn light-blue">
                        <span><?php echo e(__('product.Photo')); ?></span>
                        <input value="<?php echo e(old('image')); ?>" type="file" name="image">
                    </div>
                    <div class="file-path-wrapper">
                        <input class="file-path validate" type="text">
                    </div>
                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="row text-center">
                <div class="file-field col s12 input-field">
                    <input value="Upload Plroduct" type="submit" class="btn btn-link" value="Save">
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\amarbazar-laravel\resources\views/sales/index.blade.php ENDPATH**/ ?>