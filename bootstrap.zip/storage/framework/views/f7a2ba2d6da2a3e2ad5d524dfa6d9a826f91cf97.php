<?php $__env->startSection('title','Login-AmarBazar'); ?>
<?php $__env->startSection('auth'); ?>
<div class="section no-pad-bot" id="index-banner">
    <div class="container">
        <br><br>
        <h1 class="header center light-blue-text"><?php echo e(__('welcome.Amar Bazar')); ?></h1>
        <div class="row center">
            <h5 class="header col s12 light"><?php echo e(__('login.Login')); ?></h5>
        </div>
    </div>
</div>


<div class="container">
    <div class="section">

        <div class="row">
            <div class="col s12 m6 offset-m3">
                <div class="card">
                    <div class="card-content black-text">
                        <div class="row">



                            <form class="col s12" method="POST" action="<?php echo e(route('login')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <a class="btn right" href="<?php echo e(route('register')); ?>">
                                    <?php echo e(__('login.Registration')); ?>

                                </a>
                                <div class="row">
                                    <div class="input-field col s12">
                                        <input id="first_name" type="email" class="validate" name="email"
                                            value="<?php echo e(old('email')); ?>">
                                        <label for="first_name"><?php echo e(__('login.Email')); ?></label>
                                        <span class="helper-text" data-error="Please Enter Valid Email Address"
                                            data-success="">
                                            <?php echo e($errors->has('email') ? $errors->first('email') : ''); ?>

                                        </span>
                                    </div>
                                    <div class="input-field col s12">
                                        <input id="password" type="password" name="password" class="validate">
                                        <label for="password"><?php echo e(__('login.Password')); ?></label>
                                        <?php if($errors->has('password')): ?>
                                        <span class="helper-text">
                                            <?php echo e($errors->first('password')); ?>

                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="input-field col s12">
                                        <label>
                                            <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                            <span><?php echo e(__('login.remember')); ?></span>
                                        </label>
                                    </div>
                                </div>


                                <div class="row">
                                    <div class="col s12 center">
                                        <br>
                                        <button type="submit" class="btn btn-small">
                                            <?php echo e(__('login.Login')); ?>

                                        </button>

                                        <a class="btn btn-flat btn-small" href="<?php echo e(route('password.request')); ?>">
                                            <?php echo e(__('login.forgot')); ?>

                                        </a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <br><br>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\amarbazar-laravel\resources\views/auth/login.blade.php ENDPATH**/ ?>