<?php

return [
    'setting_create'=>'সেটিং',
    'header_create'=>'গুরত্বপূর্ণ লিংক',
    'social_create'=>'সামাজিক লিংক',
    'Price'=>'Price:',
    'Minimum Order'=>'Minimum Order:',
    'Place'=>'Place:',
    'Seller'=>'Seller:',
    'Phone'=>'Phone:',
    'site_title' => 'ওয়েবসাইটের নাম', 
    'copyright' => 'কপিরাইট', 
    'admin_email' => 'এডমিন ইমেইল',
    'seo_title' => 'এসইও টাইটেল',
    'seo_description' => 'এসইও বর্ণনা',
    'seo_keywords' => 'কি ওয়ার্ডস',
    'contact_address' => 'ঠিকানা',
    'contact_email' => 'ইমেইল',
    'contact_phone' => 'ফোন',
    'about' => 'সম্পর্কে',
    'updated_by' =>'সম্পাদক',
    'logo' =>'ছবি',
    'header_new' =>'নতুন লিংক',
    'title' =>'টাইটেল',
    'title_bn' =>'টাইটেল (বাংলা)',
    'link' =>'লিংক',
    'action' =>'একশন',
    'edit' =>'সম্পাদনা',
    'delete' =>'মুছে ফেলুন',
   

];
?>
