<?php

return [
    'Amar Bazar'=>'আমার আড়ত',
    'Everything together' => 'একসাথে সবকিছু',
    'Fast delivery' => 'দ্রুত ডেলিভারি',
    'Easy interface' => 'সহজ ইন্টারফেস',
    'Under your control' => 'আপনার নিয়ন্ত্রনে',
    'First of all' => 'সবার আগে সবচেয়ে কাছে।',
    'Do everything easily' => 'সবকিছু করতে পারবেন সহজেই',
    'Your information is under your control' => 'আপনার তথ্য আপনার নিয়ন্ত্রনে',
];
