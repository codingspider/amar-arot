<?php

return [
    'Login' => 'Login',
    'Email' => 'E-mail',
    'Password' => 'Password',
    'Registration' => 'Registration',
    'forgot' => 'Forgot your password?',
    'remember' => 'Remember me',
    'Name' => 'Name (English)',
    'Name_bn' => 'Name (Bangla)',
    'ConfirmPassword' => 'Confirm Password',

];
?>
