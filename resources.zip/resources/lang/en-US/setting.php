<?php

return [
    'setting_create'=>'Settings',
    'header_create'=>'Header Links',
    'social_create'=>'Social Links',
    'Price'=>'Price:',
    'Minimum Order'=>'Minimum Order:',
    'Place'=>'Place:',
    'Seller'=>'Seller:',
    'Phone'=>'Phone:',
    'site_title' => 'Site Title ', 
    'copyright' => 'Copyright', 
    'admin_email' => 'Admin Email',
    'seo_title' => 'Seo Title ',
    'seo_description' => 'Seo Description',
    'seo_keywords' => 'Seo Keywords',
    'contact_address' => 'Contact Address',
    'contact_email' => 'Contact Email',
    'contact_phone' => 'Contact Phone',
    'about' => 'About ',
    'updated_by' =>'Updated By',
    'logo' =>'Image'
   

];
?>
