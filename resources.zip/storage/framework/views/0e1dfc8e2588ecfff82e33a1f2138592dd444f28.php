<?php $__env->startSection('pagetitle','Order-AmarBazar'); ?>

<?php $__env->startSection('contents'); ?>
<div class="section no-pad-bot" id="index-banner">
    <div class="container">
        <br><br>
        <h1 class="header center light-blue-text"><?php echo e(__('welcome.Amar Bazar')); ?></h1>
        <div class="row center">
            <h5 class="header col s12 light"><?php echo e(__('order.Your order details')); ?></h5>
        </div>
    </div>
</div>

<div class="container">
    <div class="section">
        <!--   Icon Section   -->
        <div class="row">
            <div class="col s12">
                <?php if(session()->has('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('success')); ?>

                </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="row z-depth-1">
            <div class="col s12 m6">
                <p>
                    <?php echo e(__('order.Buyer Name')); ?> <?php echo e(Auth::user()->name); ?> <br>
                    <?php echo e(__('product.Phone')); ?> <?php echo e(Auth::user()->phone); ?> <br>
                    <?php echo e(__('order.Address')); ?> <?php echo e($address->address_line_1); ?>

                </p>
            </div>
            <div class="col s12 m4">
                <p>
                    <?php echo e(__('order.Status')); ?>: <?php echo e($express_order->status); ?> <br>
                    <?php echo e(__('order.Order no')); ?>: <?php echo e($express_order->id); ?> <br>
                    <?php echo e(__('order.Date')); ?>:<?php echo e($express_order->created_at); ?>

                </p>
            </div>
            <div class="col s12 m2">
                <p>
                    <a href="<?php echo e(route('express-orders.edit',$express_order->id)); ?>" class="btn"> Edit</a>
                    <form action="<?php echo e(route('express-orders.destroy',$express_order->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-red"> Cancel</button>
                    </form>
                </p>
            </div>
        </div>

        <div class="row">
            <div class="col s12 z-depth-1">
                <table class="responsive-table">
                    <thead>
                        <tr>
                            <th><?php echo e(__('product.Product Name')); ?></th>
                            <th><?php echo e(__('cart.Brand')); ?></th>
                            <th><?php echo e(__('cart.Quantity')); ?></th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $express_order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->name); ?></td>
                            <td><?php echo e($item->brand); ?></td>
                            <td><?php echo e($item->qty); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <br><br>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\amarbazar-laravel\resources\views/expressorders/show.blade.php ENDPATH**/ ?>