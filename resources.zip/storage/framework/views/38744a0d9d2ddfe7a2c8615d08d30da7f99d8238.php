<?php $__env->startSection('pagetitle','Cart-AmarBazar'); ?>

<?php $__env->startSection('contents'); ?>
<div class="section no-pad-bot" id="index-banner">
    <div class="container">
        <br><br>
        <h1 class="header center light-blue-text"><?php echo e(__('welcome.Amar Bazar')); ?></h1>
        <div class="row center">
            <h5 class="header col s12 light"><?php echo e(__('welcome.Everything together')); ?></h5>
        </div>
    </div>
</div>


<div class="container">
    <div class="section">
        <div class="row">
            <div class="col s12">
                <?php if(session()->has('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('success')); ?>

                </div>
                <?php endif; ?>

                <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="section">
        <!--   Icon Section   -->
        <?php if(Cart::count() > 0): ?>

        <div class="row">
            <div class="col s12">
                <table class="responsive-table">
                    <thead>
                        <tr>
                            <th width="20%"><?php echo e(__('cart.Product Name')); ?></th>
                            <th width="15%"><?php echo e(__('cart.Quantity')); ?></th>
                            <th width="20%"><?php echo e(__('cart.Unit Price')); ?></th>
                            <th width="20%"><?php echo e(__('cart.Sub Total')); ?></th>
                            <th width="25%"><?php echo e(__('cart.Action')); ?></th>
                        </tr>
                    </thead>

                    <tbody class="center-align">
                        <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <a href="<?php echo e(url('details/'.$item->id )); ?>"><?php echo e($item->name); ?></a>
                            </td>
                            <td>
                                <select class="quantity input-field" data-id="<?php echo e($item->rowId); ?>"
                                    data-productQuantity="<?php echo e($item->qty); ?>">
                                    <?php for($i = 1; $i < 5 + 1 ; $i++): ?> <option
                                        <?php echo e($item->qty == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                                    <?php endfor; ?>
                                </select>
                            </td>
                            <td>
                                <?php echo e($item->price); ?><?php echo e(__('cart.Taka')); ?>

                            </td>
                            <td>
                                <?php echo e($item->price * $item->qty); ?><?php echo e(__('cart.Taka')); ?>

                            </td>
                            <td>
                                <div class="row">
                                    <div class="col s3">
                                        <form action="<?php echo e(route('cart.destroy', $item->rowId)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger"><i
                                                    class="material-icons ">delete_forever
                                                </i></button>
                                        </form>

                                    </div>
                                    <div class="col s9 right-align">
                                        <form action="<?php echo e(route('cart.switchToSaveForLater', $item->rowId)); ?>"
                                            method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <button type="submit" class="waves-effect waves-light btn"><?php echo e(__('cart.Save for Later')); ?></button>
                                        </form>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if(session()->has('coupon')): ?>
                        <tr>

                            <td colspan="3">
                                <h3>Discount</h3>
                            </td>
                            <td class="text-right">
                                <h3><strong>৳ <?php echo e($discount); ?></strong></h3>
                            </td>
                        </tr>
                        <?php endif; ?>
                        <tr>
                            <td colspan="3">
                                <a type="button" class="btn btn-default" href="<?php echo e(url('/home')); ?>">
                                    <span class="glyphicon glyphicon-shopping-cart"></span> <?php echo e(__('cart.Continue Shopping')); ?>

                                </a>
                            </td>
                            <td colspan="2" class="right-align">
                            <a href="<?php echo e(url('/checkout')); ?>" class="btn light-blue right waves-effect waves-light"><?php echo e(__('cart.Confirm')); ?></a>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="3"></td>
                            <td colspan="2">
                                <?php if(! session()->has('coupon')): ?>
                                <a href="#" class="have-code"><?php echo e(__('cart.Have a Code?')); ?></a>
                                <div class="have-code-container">
                                    <form action="<?php echo e(route('coupon.store')); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                        <div class="row right-align">
                                            <div class="col s6">
                                                <input type="text" class="form-input" name="coupon_code"
                                                    id="coupon_code">
                                            </div>
                                            <div class="col s6">
                                                <button type="submit" class="btn btn form-input"><?php echo e(__('cart.Apply')); ?></button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <p class="center"><?php echo e(__('cart.Total')); ?> <?php echo e($newSubtotal); ?> <?php echo e(__('cart.Taka')); ?></p>
            </div>
        </div>
        <?php else: ?>
        <div class="row">
            <div class="col s12 center-align">
                <h3 class="text-center"><?php echo e(__('cart.There is no items in your cart!')); ?> </h3>
                <a class="btn btn-primary" href="<?php echo e(url('/home')); ?>"> <?php echo e(__('cart.Shop Now')); ?> </a>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <div class="section">
        <?php if(Cart::instance('saveForLater')->count() > 0): ?>
        <div class="row">
            <div class="col s12">
                <h3 class="center-align"><?php echo e(Cart::instance('saveForLater')->count()); ?> <?php echo e(__('cart.item(s)')); ?> <?php echo e(__('cart.Saved For Later')); ?></h3>
            </div>
        </div>
        <div class="row">
            <div class="col s12">
                <table class="responsive-table">
                    <thead>
                        <tr>
                            <th width="20%"><?php echo e(__('cart.Product Name')); ?></th>
                            <th width="15%"><?php echo e(__('cart.Quantity')); ?></th>
                            <th width="20%"><?php echo e(__('cart.Unit Price')); ?></th>
                            <th width="20%"><?php echo e(__('cart.Sub Total')); ?></th>
                            <th width="25%"><?php echo e(__('cart.Action')); ?></th>
                        </tr>
                    </thead>

                    <tbody class="center-align">
                        <?php $__currentLoopData = Cart::instance('saveForLater')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <a href="<?php echo e(url('details/'.$item->id )); ?>"><?php echo e($item->name); ?></a>
                            </td>
                            <td>
                                <?php echo e($item->qty); ?>

                            </td>
                            <td>
                                <?php echo e($item->price); ?><?php echo e(__('cart.Taka')); ?>

                            </td>
                            <td>
                                <?php echo e($item->price * $item->qty); ?><?php echo e(__('cart.Taka')); ?>

                            </td>


                            <td class="right-align">
                                <div class="row">
                                    <div class="col s3">
                                        <form action="<?php echo e(route('saveForLater.destroy', $item->rowId)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger"><i
                                                    class="material-icons ">delete_forever
                                                </i></button>
                                        </form>

                                    </div>
                                    <div class="col s9">
                                        <form action="<?php echo e(route('saveForLater.switchToCart', $item->rowId)); ?>"
                                            method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <button type="submit" class="waves-effect waves-light btn"><?php echo e(__('cart.Move to Cart')); ?></button>
                                        </form>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>
        <?php else: ?>

        <div class="row">
            <div class="col s12 ">
                <h3 class="center-align">You have no items saved for later. </h3>
            </div>
        </div>
        <?php endif; ?>

    </div>


</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script>
    (function () {
        const classname = document.querySelectorAll('.quantity')
        Array.from(classname).forEach(function (element) {
            element.addEventListener('change', function () {
                const id = element.getAttribute('data-id')
                const productQuantity = element.getAttribute('data-productQuantity')
                axios.patch(`/cart/${id}`, {
                    quantity: this.value,
                    productQuantity: productQuantity
                })
                    .then(function (response) {
                        console.log(response);
                        window.location.href = "<?php echo e(route('cart.index')); ?>"
                    })
                    .catch(function (error) {
                        console.log(error);
                        window.location.href = "<?php echo e(route('cart.index')); ?>"
                    });
            })
        })
    })();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\amarbazar-laravel\resources\views/carts/show.blade.php ENDPATH**/ ?>