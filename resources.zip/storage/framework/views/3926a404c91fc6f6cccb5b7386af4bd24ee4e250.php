<?php $__env->startSection('auth'); ?>
<div class="section no-pad-bot" id="index-banner">
    <div class="container">
        <br><br>
        <h1 class="header center light-blue-text"><?php echo e(__('welcome.Amar Bazar')); ?></h1>
        <div class="row center">
            <h5 class="header col s12 light"><?php echo e(__('login.Registration')); ?></h5>
        </div>
    </div>
</div>
<div class="container">
    <div class="section">
        <div class="row">
            <div class="col s12 m6 offset-m3">
                <div class="card">
                    <div class="card-content black-text">
                        <div class="row">
                            <form class="col s12" method="POST" action="<?php echo e(route('register')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <a href="<?php echo e(url('login')); ?>" class="btn btn-link right"><?php echo e(__('login.Login')); ?></a>
                                <div class="row">
                                    <div class="input-field col s12">
                                        <input id="first_name" type="text" class="validate" value="<?php echo e(old('name')); ?>" name="name">
                                        <label for="first_name"><?php echo e(__('login.Name')); ?></label>
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="helper-text">
                                            <?php echo e($message); ?>

                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="input-field col s12">
                                        <input id="name" type="text" class="validate" value="<?php echo e(old('name_bn')); ?>" name="name_bn">
                                        <label for="name"><?php echo e(__('login.Name_bn')); ?></label>
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="helper-text">
                                            <?php echo e($message); ?>

                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="input-field col s12">
                                        <input id="email" type="email" class="validate" value="<?php echo e(old('email')); ?>" name="email">
                                        <label for="email"><?php echo e(__('login.Email')); ?></label>
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="helper-text">
                                            <?php echo e($message); ?>

                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="input-field col s12">
                                        <input id="password" type="password" class="validate" value="<?php echo e(old('password')); ?>" name="password">
                                        <label for="password"><?php echo e(__('login.Password')); ?></label>
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="helper-text">
                                            <?php echo e($message); ?>

                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="input-field col s12">
                                        <input id="password-confirm" type="password" class="validate" value="<?php echo e(old('password-confirm')); ?>" name="password_confirmation">
                                        <label for="password-confirm"><?php echo e(__('login.ConfirmPassword')); ?></label>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col s12 center">
                                        <button type="submit" class="btn btn-link">
                                            <?php echo e(__('login.Registration')); ?>

                                        </button>
                                    </div>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <br><br>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\amarbazar-laravel\resources\views/auth/register.blade.php ENDPATH**/ ?>