<?php $__env->startSection('contents'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="row mt-5">
        <div class="col-lg-12 margin-tb">
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('users.index')); ?>"> Back</a>
            </div>
        </div>
    </div>
    <div class="row">
        <form action="<?php echo e(route('users.update',$user->id )); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('PATCH')); ?>

            <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
            <div class="row">
                <div class="input-field col s6">
                    <input placeholder="Placeholder" id="first_name" name="name" value="<?php echo e($user->name); ?>" type="text"
                        class="validate">
                    <label for="first_name">Name</label>
                </div>
                <div class="input-field col s6">
                    <input placeholder="Placeholder" name="name_bn" value="<?php echo e($user->name_bn); ?>" id="name_bn"
                        type="text" class="validate">
                    <label for="first_name">Bangla Name</label>
                </div>

            </div>

            <div class="row">
                <div class="input-field col s12">
                    <input id="email" type="email" name="email" value="<?php echo e($user->email); ?>" class="validate" disabled>
                    <label for="email">Email</label>
                </div>
            </div>

            <div class="row">
                <div class="input-field col s12">
                    <div class="input-field col s12">
                        <select name="roles[]" multiple>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                        <label> Select Role</label>
                    </div>

                </div>
            </div>
            <div class="row">
                <div class="input-field col s12">

                    <button class="waves-effect waves-light btn" type="submit"> Submit </button>
                </div>
            </div>



        </form>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\amarbazar-laravel\resources\views/users/edit.blade.php ENDPATH**/ ?>