<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0" />
    <title><?php echo $__env->yieldContent('pagetitle','Optima'); ?></title>

    <!-- CSS  -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="<?php echo e(asset('content')); ?>/css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection" />
    <link href="<?php echo e(asset('content')); ?>/css/style.css" type="text/css" rel="stylesheet" media="screen,projection" />

    <!-- PWA Links -->

    <link rel="icon" href="<?php echo e(asset('content')); ?>/img/favicon.ico" type="image/x-icon" />

    <!-- CODELAB: Add link rel manifest -->
    <link rel="manifest" href="<?php echo e(asset('manifest.json')); ?>">
    <!-- CODELAB: Add iOS meta tags and icons -->
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="Amar Bazaar">
    <link rel="apple-touch-icon" href="<?php echo e(asset('content')); ?>/img/icons/icon-152x152.png">
    <!-- social media-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- CODELAB: Add description here -->
    <meta name="description" content="Amar Bazaar">
    <!-- CODELAB: Add meta theme-color -->
    <meta name="theme-color" content="#2F3BA2" />
    
</head>

<body>
    <?php echo $__env->make('layouts.partial.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('contents'); ?>
    <?php echo $__env->make('layouts.partial.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script src="<?php echo e(asset('content')); ?>/js/materialize.js"></script>
    <script src="<?php echo e(asset('content')); ?>/js/install.js"></script>
    <script src="<?php echo e(asset('content')); ?>/js/init.js?v=1"></script>
    <?php echo $__env->yieldContent('script'); ?>

</body>

</html>
<?php /**PATH C:\laragon\www\amarbazar-laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>