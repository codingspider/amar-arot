<?php $__env->startSection('contents'); ?>
<br>
    <div class="container">
        <?php if($errors->any()): ?>
            <?php echo e(implode('', $errors->all(':message'))); ?>

        <?php endif; ?>
    <div class="row">
        <form class="col s12" action="<?php echo e(route('settings.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
        <div class="row">
            <div class="input-field col s6">
            <input placeholder="Placeholder" id="first_name" name="site_title" value="<?php echo e(old('site_title')); ?> <?php echo e(isset($var->site_title)? $var->site_title : ''); ?>" type="text" class="validate">
            <label for="first_name"><?php echo e(__('setting.site_title')); ?></label>
            </div>
            <div class="input-field col s6">
            <input placeholder="Placeholder" id="first_name" name="copyright" value="<?php echo e(old('copyright')); ?> <?php echo e(isset($var->copyright)? $var->copyright : ''); ?>" type="text" class="validate">
            <label for="first_name"><?php echo e(__('setting.copyright')); ?> </label>
            </div>
        </div>
        <div class="row">
            <div class="input-field col s6">
            <input placeholder="Placeholder" id="first_name" name="admin_email" type="text" value="<?php echo e(old('admin_email')); ?> <?php echo e(isset($var->admin_email)? $var->admin_email : ''); ?>" class="validate">
            <label for="first_name"><?php echo e(__('setting.admin_email')); ?></label>
            </div>
            <div class="input-field col s6">
            <input placeholder="Placeholder" id="first_name" name="seo_title" type="text" value="<?php echo e(old('seo_title')); ?> <?php echo e(isset($var->seo_title)? $var->seo_title : ''); ?>" class="validate">
            <label for="first_name"><?php echo e(__('setting.seo_title')); ?> </label>
            </div>
        </div>
        <div class="row">
            <div class="input-field col s6">
             <textarea id="textarea1" name="description" class="materialize-textarea"><?php echo e(old('description')); ?> <?php echo e(isset($var->description)? $var->description : ''); ?></textarea>
            <label for="first_name"><?php echo e(__('setting.seo_description')); ?></label>
            </div>
            <div class="input-field col s6">
            <input placeholder="Placeholder" id="first_name" name="seo_keywords" type="text" value="<?php echo e(old('seo_keywords')); ?> <?php echo e(isset($var->seo_keywords)? $var->seo_keywords : ''); ?>" class="validate">
            <label for="first_name"><?php echo e(__('setting.seo_keywords')); ?> </label>
            </div>
        </div>
        <div class="row">
            <div class="input-field col s6">
            <textarea class="materialize-textarea" id="val-suggestions"  name="contact_address" rows="5" placeholder="What would you like to see?"><?php echo e(old('contact_address')); ?> <?php echo e(isset($var->contact_address)? $var->contact_address : ''); ?></textarea>
            <label for="first_name"><?php echo e(__('setting.contact_address')); ?></label>
            </div>
            <div class="input-field col s6">
            <input placeholder="Placeholder" id="first_name" name="contact_email" value="<?php echo e(old('contact_email')); ?> <?php echo e(isset($var->contact_email)? $var->contact_email : ''); ?>" type="text" class="validate">
            <label for="first_name"><?php echo e(__('setting.contact_email')); ?> </label>
            </div>
        </div>
        <div class="row">
            <div class="input-field col s6">
            <input placeholder="Placeholder" id="first_name" name="contact_phone" type="text" value="<?php echo e(old('contact_phone')); ?> <?php echo e(isset($var->contact_phone)? $var->contact_phone : ''); ?>" class="validate">
            <label for="first_name"><?php echo e(__('setting.contact_phone')); ?></label>
            </div>
            <div class="input-field col s6">
            <textarea id="textarea1" name="about" class="materialize-textarea"><?php echo e(old('about')); ?> <?php echo e(isset($var->about)? $var->about : ''); ?></textarea>
            <label for="first_name"><?php echo e(__('setting.about')); ?> </label>
            </div>
        </div>
        <div class="row">
            <div class="input-field col s6">
                <label for="first_name"><?php echo e(__('setting.logo')); ?></label><br><br>
            <input placeholder="Placeholder" id="first_name" name="images" type="file" >
            </div>
            <div class="input-field col s6">
            <textarea id="textarea1" name="about" class="materialize-textarea"><?php echo e(old('about')); ?> <?php echo e(isset($var->about)? $var->about : ''); ?></textarea>
            <label for="first_name"><?php echo e(__('setting.about')); ?> </label>
            </div>
        </div>
        <div class="row">
            <button class="waves-effect waves-light btn" type="submit"> Submit </button>
        </div>


    </form>
  </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\amarbazar-laravel\resources\views/setting/create_setting.blade.php ENDPATH**/ ?>