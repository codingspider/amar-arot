<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/all.css">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <title>Cart List </title>
</head>

<body>

    <div class="container">
        <br>
        <p class="text-center">Items in cart <a href="#" target="_blank"></a></p>

        <?php if(session()->has('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('success')); ?>

        </div>
        <?php endif; ?>

        <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>


        <hr>


        <?php if(Cart::count() > 0): ?>
        <h3> You have <?php echo e(Cart::count()); ?> products in your cart. </h3>
        <div class="col-md-12">
            <div class="row">
                <div class="col-sm-12 col-md-12 col-md-offset-1">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Quantity</th>
                                <th class="text-center">Price</th>
                                <th class="text-center">Total</th>
                                <th> </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td class="col-sm-12 col-md-8">
                                    <div class="media">
                                        <a class="thumbnail pull-left" href="<?php echo e(url('details/'.$item->id )); ?>"> <img
                                                class="media-object" src="<?php echo e(asset('uploads/'.$item->model->image)); ?>"
                                                style="width: 50px; height: 50px;"> </a>
                                        <div class="media-body">
                                            <h5 style=" padding-left:20px;" class="media-heading"> <a
                                                    href="<?php echo e(url('details/'.$item->id )); ?>"> <?php echo e($item->name); ?></a></h5>

                                        </div>
                                    </div>
                                </td>
                                <td class="col-sm-2 col-md-2" style="text-align: center">
                                    <select class="quantity" data-id="<?php echo e($item->rowId); ?>"
                                        data-productQuantity="<?php echo e($item->model->quantity); ?>">
                                        <?php for($i = 1; $i < 5 + 1 ; $i++): ?> <option
                                            <?php echo e($item->qty == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                                            <?php endfor; ?>
                                    </select>
                                </td>
                                <td class="col-sm-2 col-md-2 text-center"><strong>৳ <?php echo e($item->price); ?></strong></td>
                                <td class="col-sm-2 col-md-2 text-center"><strong>৳
                                        <?php echo e($item->price * $item->qty); ?></strong></td>
                                <td class="col-md-4">
                                    <form action="<?php echo e(route('cart.destroy', $item->rowId)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger">Remove</button>
                                    </form>
                                    <form action="<?php echo e(route('cart.switchToSaveForLater', $item->rowId)); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>


                                        <button type="submit" class="cart-options">Save for Later</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td> </td>
                                <td> </td>
                                <td> </td>
                                <?php if(session()->has('coupon')): ?>
                                <td>
                                    <h5>Discount (<?php echo e(session()->get('coupon')['name']); ?>) </h5>
                                </td>
                                <td class="text-right text-center">
                                    <h5><strong>-৳ <?php echo e(session()->get('coupon')['discount']); ?> %</strong></h5>
                                </td>
                                <form action="<?php echo e(route('coupon.destroy')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo e(method_field('delete')); ?>

                                    <td><button class="btn btn-danger" type="submit">Remove </button></td>
                                </form>
                                <?php endif; ?>
                            </tr>
                            <tr>
                                <td>   </td>
                                <td>   </td>
                                <td>   </td>
                                <td>
                                    <h5>TAX</h5>
                                </td>
                                <td class="text-right">
                                    <h5><strong>৳ <?php echo e(Cart::tax()); ?></strong></h5>
                                </td>
                            </tr>
                            <?php if(session()->has('coupon')): ?>
                            <tr>
                                <td>   </td>
                                <td>   </td>
                                <td> </td>
                                <td>
                                    <h3>Discount</h3>
                                </td>
                                <td class="text-right">
                                    <h3><strong>৳ <?php echo e($discount); ?></strong></h3>
                                </td>
                            </tr>
                            <?php endif; ?>
                            <tr>
                                <td>   </td>
                                <td>   </td>
                                <td> </td>
                                <td>
                                    <h3>Total</h3>
                                </td>
                                <td class="text-right">
                                    <h3><strong>৳ <?php echo e($newSubtotal); ?></strong></h3>
                                </td>
                            </tr>
                            <tr>
                                <td>   </td>
                                <td>   </td>
                                <td>   </td>
                                <td>
                                    <button type="button" class="btn btn-default">
                                        <span class="glyphicon glyphicon-shopping-cart"></span> Continue Shopping
                                    </button></td>
                                <td>
                                    <button type="button" class="btn btn-success">
                                        Checkout <span class="glyphicon glyphicon-play"></span>
                                    </button></td>
                            </tr>
                            <tr>
                                <td>
                                    <?php if(! session()->has('coupon')): ?>

                                    <a href="#" class="have-code">Have a Code?</a>

                                    <div class="have-code-container">
                                        <form action="<?php echo e(route('coupon.store')); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="text" name="coupon_code" id="coupon_code">
                                            <button type="submit" class="button button-plain">Apply</button>
                                        </form>
                                    </div> <!-- end have-code-container -->
                                    <?php endif; ?>
                                </td>
                            </tr>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
        <?php else: ?>
        <h3 class="text-center">There is no items in your cart! </h3>
        <a class="btn btn-primary" href="<?php echo e(url('/home')); ?>"> Shop Now </a>
        <?php endif; ?>

        <?php if(Cart::instance('saveForLater')->count() > 0): ?>

        <h2><?php echo e(Cart::instance('saveForLater')->count()); ?> item(s) Saved For Later</h2>
        <div class="col-md-12">
            <div class="row">
                <div class="col-sm-12 col-md-12 col-md-offset-1">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Product</th>

                                <th class="text-center">Price</th>
                                <th> </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = Cart::instance('saveForLater')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td class="col-sm-12 col-md-8">
                                    <div class="media">
                                        <a class="thumbnail pull-left" href="<?php echo e(url('details/'.$item->id )); ?>"> <img
                                                class="media-object" src="<?php echo e(asset('uploads/'.$item->model->image)); ?>"
                                                style="width: 50px; height: 50px;"> </a>
                                        <div class="media-body">
                                            <h5 style=" padding-left:20px;" class="media-heading"> <a
                                                    href="<?php echo e(url('details/'.$item->id )); ?>"> <?php echo e($item->name); ?></a></h5>

                                        </div>
                                    </div>
                                </td>

                                <td class="col-sm-2 col-md-2 text-center"><strong>৳ <?php echo e($item->price); ?></strong></td>

                                <td class="col-md-4">
                                    <form action="<?php echo e(route('saveForLater.destroy', $item->rowId)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger">Remove</button>
                                    </form>

                                    <form action="<?php echo e(route('saveForLater.switchToCart', $item->rowId)); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>


                                        <button type="submit" class="cart-options">Move to Cart</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                    </table>

                </div>
            </div>
        </div>
        <?php else: ?>
        <h3 class="text-center">You have no items saved for later. </h3>

        <?php endif; ?>
    </div>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script>
        (function () {
            const classname = document.querySelectorAll('.quantity')
            Array.from(classname).forEach(function (element) {
                element.addEventListener('change', function () {
                    const id = element.getAttribute('data-id')
                    const productQuantity = element.getAttribute('data-productQuantity')
                    axios.patch(`/cart/${id}`, {
                        quantity: this.value,
                        productQuantity: productQuantity
                    })
                        .then(function (response) {
                            // console.log(response);
                            window.location.href = "<?php echo e(route('cart.index')); ?>"
                        })
                        .catch(function (error) {
                            // console.log(error);
                            window.location.href = "<?php echo e(route('cart.index')); ?>"
                        });
                })
            })
        })();
    </script>
</body>

</html>
<?php /**PATH C:\laragon\www\amarbazar-laravel\resources\views/cart/cart.blade.php ENDPATH**/ ?>