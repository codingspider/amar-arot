<nav class="light-blue lighten-1" role="navigation">
    <div class="nav-wrapper container"><a id="logo-container" href="<?php echo e(url('home')); ?>"
            class="brand-logo"><?php echo e(__('welcome.Amar Bazar')); ?></a>
        <a href="#" data-target="slide-out" class="sidenav-trigger show-on-medium-and-up right"><i
                class="material-icons">menu</i></a>
    </div>
</nav>

<ul id="slide-out" class="sidenav light-blue">
    <?php if(Auth::check()): ?>
    <li>
        <div class="user-view">
            <div class="background">
                <img src="<?php echo e(asset('content')); ?>/img/cover.jpg">
            </div>
            <a href="#user"><img class="circle" src="<?php echo e(asset('content')); ?>/img/profile.png"></a>
            <a href="#name"><span class="white-text name"><?php echo e(Auth::user()->name); ?></span></a>
            <a href="#email"><span class="white-text email"><?php echo e(Auth::user()->email); ?></span></a>
        </div>
    </li>
    <li><a class="white-text waves-effect" href="<?php echo e(route('profiles.show',Auth::user()->id)); ?>"><i
        class="material-icons white-text">account_circle</i><?php echo e(__('nav.Profile')); ?></a>
    </li>
    <li>
        <div class="divider"></div>
    </li>
    <?php endif; ?>
    <!-- <li><a href="#!">Second Link</a></li> -->
    <li><a class="waves-effect white-text" href="<?php echo e(route('sales.index')); ?>"><i
                class="material-icons white-text">add_box</i><?php echo e(__('nav.Sale')); ?></a>
    </li>
    <li><a class="waves-effect white-text" href="<?php echo e(url('orders')); ?>"><i
                class="material-icons white-text">add_box</i><?php echo e(__('nav.Orders')); ?></a></li>
    <li>
    <li><a class="waves-effect white-text" href="<?php echo e(url('express-orders')); ?>"><i
                class="material-icons white-text">add_box</i><?php echo e(__('nav.Express Order')); ?></a></li>
    <li>
        <div class="divider"></div>
    </li>
    <li id="butInstall" hidden><a class="waves-effect white-text"><i
                class="material-icons white-text">arrow_downward</i><?php echo e(__('nav.Install')); ?></a></li>

    <li id="butRefresh"><a class="waves-effect white-text"><i
                class="material-icons white-text">refresh</i><?php echo e(__('nav.Refresh')); ?></a>
    </li>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-list')): ?>

    <li id="butRefresh"><a href="<?php echo e(route('users.index')); ?>" class="waves-effect white-text"><i
                class="material-icons white-text">people</i><?php echo e(__('nav.Manage_user')); ?></a>
    </li>
    <li id="butRefresh"><a href="<?php echo e(URL::to('all/orders/for/admin')); ?>" class="waves-effect white-text"><i
                class="material-icons white-text">apps</i><?php echo e(__('nav.Manage_order')); ?></a>
    </li>
    <li id="butRefresh"><a href="<?php echo e(route('roles.index')); ?>" class="waves-effect white-text"><i
                class="material-icons white-text">device_hub</i><?php echo e(__('nav.Manage_role')); ?></a>
    </li>
    <li id="butRefresh"><a href="<?php echo e(route('products.index')); ?>" class="waves-effect white-text"><i
                class="material-icons white-text">local_offer</i><?php echo e(__('nav.Manage_product')); ?></a>
    </li>
    <li id="butRefresh"><a href="<?php echo e(route('catagories.index')); ?>" class="waves-effect white-text"><i
                class="material-icons white-text">palette</i><?php echo e(__('nav.catagory')); ?></a>
    </li>
    <li id="butRefresh"><a href="<?php echo e(route('settings.create')); ?>" class="waves-effect white-text"><i
                class="material-icons white-text">build</i><?php echo e(__('setting.setting_create')); ?></a>
    </li>
    <li id="butRefresh"><a href="<?php echo e(route('headers.index')); ?>" class="waves-effect white-text"><i
                class="material-icons white-text">format_align_justify</i><?php echo e(__('setting.header_create')); ?></a>
    </li>
    <li id="butRefresh"><a href="<?php echo e(route('socials.index')); ?>" class="waves-effect white-text"><i
                class="material-icons white-text">device_hub</i><?php echo e(__('setting.social_create')); ?></a>
    </li>
    <li id="butRefresh"><a href="<?php echo e(route('measurments.index')); ?>" class="waves-effect white-text"><i
                class="material-icons white-text">palette</i><?php echo e(__('nav.measurments')); ?></a>
    </li>
    <li id="butRefresh"><a href="<?php echo e(route('coupons.index')); ?>" class="waves-effect white-text"><i
                class="material-icons white-text">local_offer</i><?php echo e(__('cart.coupons')); ?></a>
    </li>
    <?php endif; ?>
    <li>
        <div class="divider"></div>
    </li>


    <?php if(App::getLocale() == 'en-US'): ?>
    <li>
        <a class="waves-effect white-text" href="<?php echo e(url('/locale/bn-BD')); ?>">
            <i class="material-icons white-text">airplanemode_active</i>
            বাংলা
        </a>
    </li>
    <?php else: ?>
    <li>
        <a class="waves-effect white-text" href="<?php echo e(url('/locale/en-US')); ?>">
            <i class="material-icons white-text">airplanemode_active</i>
            English
        </a>
    </li>
    <?php endif; ?>
    <li>
        <?php if(Auth::check()): ?>
        <a class="waves-effect white-text" href="<?php echo e(route('logout')); ?>"
            onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
            <i class="material-icons white-text">keyboard_return</i>
            <?php echo e(__('nav.logout')); ?>

        </a>


        <?php else: ?>

        <a class="waves-effect white-text" href="<?php echo e(route('login')); ?>">
            <i class="material-icons white-text">keyboard_tab</i>
            <?php echo e(__('nav.login')); ?>

        </a>
        <?php endif; ?>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
    </li>
</ul>
<?php /**PATH C:\laragon\www\amarbazar-laravel\resources\views/layouts/partial/nav.blade.php ENDPATH**/ ?>