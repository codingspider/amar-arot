<?php $__env->startSection('contents'); ?>
    <div class="container">
      <div class="row">
      <form class="col s12" action="<?php echo e(url('confirm/order')); ?>" method="POST">
        <?php echo csrf_field(); ?>
      <div class="row">
        <div class="input-field col s6">
        <input id="last_name" type="text" name="name" value="<?php echo e(Auth::user()->name); ?>" class="validate">
          <label for="last_name">Name</label>
        </div>
        <div class="input-field col s6">
          <input id="name" type="text" name="name_bn" value="<?php echo e(Auth::user()->name_bn); ?>" class="validate">
          <label for="name_bn">Name Bangla</label>
        </div>
      </div>
      <div class="row">
        <div class="input-field col s6">
        <input id="adress_1" type="text" name="address_1" value="<?php if(isset($address->address_line_1)): ?> <?php echo e($address->address_line_1); ?> <?php endif; ?>" class="validate">
          <label for="adress_1">Address Line 1</label>
        </div>
        <div class="input-field col s6">
          <input id="adress_2" type="text" name="address_2" value="<?php if(isset($address->address_line_2)): ?> <?php echo e($address->address_line_2); ?> <?php endif; ?>" class="validate">
          <label for="adress_2">Address Line 2</label>
        </div>
      </div>
      <div class="row">
        <div class="input-field col s12">
           <select class="input-field col s12" name="district">
              <option value=""> Select your district </option>
              <?php $__currentLoopData = $district; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                      
                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name_bn); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            </select>
      
        </div>
      <div class="row">
        <div class="input-field col s12">
      <label>
        <input type="checkbox" name="shipping" class="filled-in" value="1" checked="checked" />
        <span>Shipping addres</span>
      </label>
      
        </div>
       
      </div>

      <div class="row">
        <div class="input-field col s12">
           <button class="btn btn-info" type="submit">Confirm your order </button>
      
        </div>
       
      </div>

    </form>
  </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\amarbazar-laravel\resources\views/cart/checkout.blade.php ENDPATH**/ ?>